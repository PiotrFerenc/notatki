using Spectre.Console;

namespace CodeAgent.Ui;

/// <summary>Claude-Code-flavored rendering: rounded banner, dim "● Tool(args)" call lines, "⎿" result
/// lines, a bordered confirm panel instead of a bare y/n. Assistant text streams as plain text (not run
/// through Spectre's markup parser) since model output can contain literal '[' / ']' that would break it.</summary>
public sealed class SpectreConsoleUi : IConsoleUi
{
    public void ShowBanner(string model, string cwd, bool resumedSession)
    {
        var body = new Markup($"[bold]✳ CodeAgent[/]\n[grey]model:[/] {Markup.Escape(model)}    [grey]cwd:[/] {Markup.Escape(cwd)}");
        var panel = new Panel(body)
            .RoundedBorder()
            .BorderColor(Color.Grey)
            .Padding(1, 0);

        AnsiConsole.Write(panel);

        if (resumedSession)
            AnsiConsole.MarkupLine("[grey]wznowiono poprzednią sesję[/]");

        AnsiConsole.MarkupLine("[grey]/help — lista komend, /exit — wyjście, ![/][grey]polecenie — uruchom bezpośrednio w powłoce[/]");
        AnsiConsole.WriteLine();
    }

    public string? ReadInput()
    {
        AnsiConsole.Markup("[bold dodgerblue1]>[/] ");
        return Console.ReadLine();
    }

    public void ShowToolCall(string name, string argsSummary)
    {
        var suffix = argsSummary.Length == 0 ? "" : $"[grey]({Markup.Escape(argsSummary)})[/]";
        AnsiConsole.MarkupLine($"[grey]●[/] [bold]{Markup.Escape(name)}[/]{suffix}");
    }

    public void ShowToolResult(string resultSummary)
    {
        AnsiConsole.MarkupLine($"  [grey]⎿[/] [grey]{Markup.Escape(resultSummary)}[/]");
    }

    public void WriteAssistantChunk(string text) => Console.Write(text);

    public void EndAssistantTurn() => Console.WriteLine();

    public Task<T> WithSpinnerAsync<T>(string label, Func<Task<T>> action) =>
        AnsiConsole.Status()
            .Spinner(Spinner.Known.Dots)
            .SpinnerStyle(Style.Parse("dodgerblue1"))
            .StartAsync(label, _ => action());

    public ConfirmResult Confirm(string toolName, string argsSummary)
    {
        var body = argsSummary.Length == 0 ? new Markup("(brak argumentów)") : RenderDiffish(argsSummary);
        var panel = new Panel(body)
            .Header($"[yellow]{Markup.Escape(toolName)}[/]")
            .RoundedBorder()
            .BorderColor(Color.Yellow)
            .Padding(1, 0);

        AnsiConsole.Write(panel);
        AnsiConsole.Markup("[yellow]Zezwolić?[/] [grey](y/n/a = zawsze dla tego narzędzia)[/] ");

        var answer = Console.ReadLine()?.Trim().ToLowerInvariant();
        Console.WriteLine();

        return answer switch
        {
            "a" => ConfirmResult.AlwaysAllow,
            "y" => ConfirmResult.Allow,
            _ => ConfirmResult.Deny,
        };
    }

    public void ShowInfo(string message) => AnsiConsole.MarkupLine($"[grey]{Markup.Escape(message)}[/]");

    public void ShowError(string message) => AnsiConsole.MarkupLine($"[red]{Markup.Escape(message)}[/]");

    public void ShowShellCommand(string command) =>
        AnsiConsole.MarkupLine($"[bold dodgerblue1]![/] [grey]{Markup.Escape(command)}[/]");

    /// <summary>Colors lines by convention: a leading "- " is a removal (red), "+ " is an addition (green).
    /// Tools that don't produce diff-shaped text just render as plain escaped lines.</summary>
    private static Markup RenderDiffish(string text)
    {
        var lines = text.TrimEnd('\n').Split('\n').Select(line => line switch
        {
            _ when line.StartsWith("- ", StringComparison.Ordinal) => $"[red]{Markup.Escape(line)}[/]",
            _ when line.StartsWith("+ ", StringComparison.Ordinal) => $"[green]{Markup.Escape(line)}[/]",
            _ => Markup.Escape(line),
        });

        return new Markup(string.Join('\n', lines));
    }
}
