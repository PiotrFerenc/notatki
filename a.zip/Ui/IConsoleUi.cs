namespace CodeAgent.Ui;

/// <summary>
/// Strategy/Facade: every bit of terminal presentation goes through here, so <see cref="Repl.ReplSession"/>
/// and <see cref="Permissions.ConsolePermissionGate"/> never touch <see cref="Console"/> directly.
/// </summary>
public interface IConsoleUi
{
    void ShowBanner(string model, string cwd, bool resumedSession);

    /// <summary>Prints the "&gt; " prompt and reads one line. Deliberately plain <c>Console.ReadLine</c>
    /// under the hood (not a Spectre input widget) so piped/non-interactive stdin keeps working.</summary>
    string? ReadInput();

    void ShowToolCall(string name, string argsSummary);

    void ShowToolResult(string resultSummary);

    void WriteAssistantChunk(string text);

    void EndAssistantTurn();

    /// <summary>Runs <paramref name="action"/> behind a spinner, for the gap before the first streamed token.</summary>
    Task<T> WithSpinnerAsync<T>(string label, Func<Task<T>> action);

    ConfirmResult Confirm(string toolName, string argsSummary);

    /// <summary>A dim, non-conversational status line — used by slash commands (/config, /model, /clear).</summary>
    void ShowInfo(string message);

    void ShowError(string message);

    /// <summary>Echoes a "!command" the user typed directly, before it runs — same idea as a shell prompt
    /// echoing what you typed.</summary>
    void ShowShellCommand(string command);
}
