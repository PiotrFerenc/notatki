namespace CodeAgent.Ui;

public enum ConfirmResult
{
    Deny,
    Allow,

    /// <summary>Approve this call and every future call to the same tool for the rest of the process.</summary>
    AlwaysAllow,
}
