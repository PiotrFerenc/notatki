using CodeAgent.Config;
using CodeAgent.Tools;
using CodeAgent.Verification;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CodeAgent.Agent;

public sealed class ChatAgentBuilder : IChatAgentBuilder
{
    private readonly AgentOptions _options;
    private readonly IChatClientProvider _clientProvider;
    private readonly IToolFunctionAdapter _toolAdapter;
    private readonly IProjectCommandDetector _commandDetector;
    private readonly ILoggerFactory _loggerFactory;

    public ChatAgentBuilder(
        IOptions<AgentOptions> options,
        IChatClientProvider clientProvider,
        IToolFunctionAdapter toolAdapter,
        IProjectCommandDetector commandDetector,
        ILoggerFactory loggerFactory)
    {
        _options = options.Value;
        _clientProvider = clientProvider;
        _toolAdapter = toolAdapter;
        _commandDetector = commandDetector;
        _loggerFactory = loggerFactory;
    }

    public AIAgent Build(IEnumerable<ITool> tools)
    {
        IChatClient chatClient = _clientProvider.GetChatClient(_options.Model);

        var commands = _commandDetector.Detect(Directory.GetCurrentDirectory());
        var instructions = SystemPrompt.Build(commands);

        IList<AITool> aiTools = tools.Select(_toolAdapter.Adapt).ToList();

        // Framework default is 40 iterations/turn; make the cap explicit and ours to tune instead of
        // an implicit constant nobody controls.
        var wrapped = new FunctionInvokingChatClient(chatClient, _loggerFactory)
        {
            MaximumIterationsPerRequest = _options.MaxToolIterationsPerTurn,
            // Our tools mostly return error strings rather than throw, but the paths that do throw
            // (a malformed regex, a permission-denied on disk) were otherwise invisible to the model —
            // it saw a generic failure with no way to self-correct.
            IncludeDetailedErrors = true,
        };

        return new ChatClientAgent(
            wrapped,
            new ChatClientAgentOptions
            {
                Name = "CodeAgent",
                Description = "A coding assistant agent",
                ChatOptions = new ChatOptions { Instructions = instructions, Tools = aiTools },
            },
            _loggerFactory);
    }
}
