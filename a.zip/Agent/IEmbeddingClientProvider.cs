using OpenAI.Embeddings;

namespace CodeAgent.Agent;

/// <summary>Separate seam from <see cref="IChatClientProvider"/>: embeddings have no equivalent
/// framework-wide abstraction here, so this stays OpenAI-shaped on purpose.</summary>
public interface IEmbeddingClientProvider
{
    EmbeddingClient GetEmbeddingClient(string model);
}
