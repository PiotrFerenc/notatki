using System.ClientModel;
using CodeAgent.Config;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Options;
using OpenAI;
using OpenAI.Embeddings;

namespace CodeAgent.Agent;

/// <summary>OpenAI-backed implementation of both provider seams. Swapping to another chat provider
/// means writing a new <see cref="IChatClientProvider"/>, not touching either interface.</summary>
public sealed class OpenAIClientProvider : IChatClientProvider, IEmbeddingClientProvider
{
    private readonly OpenAIClient _client;

    public OpenAIClientProvider(IOptions<AgentOptions> options)
    {
        var agentOptions = options.Value;
        var clientOptions = new OpenAIClientOptions();
        if (!string.IsNullOrWhiteSpace(agentOptions.BaseUrl))
            clientOptions.Endpoint = new Uri(agentOptions.BaseUrl);

        _client = new OpenAIClient(new ApiKeyCredential(agentOptions.ApiKey), clientOptions);
    }

    public IChatClient GetChatClient(string model) => _client.GetChatClient(model).AsIChatClient();

    public EmbeddingClient GetEmbeddingClient(string model) => _client.GetEmbeddingClient(model);
}
