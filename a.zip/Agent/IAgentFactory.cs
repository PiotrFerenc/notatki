using CodeAgent.Tools;
using Microsoft.Agents.AI;

namespace CodeAgent.Agent;

/// <summary>Factory pattern: builds the configured <see cref="AIAgent"/> instance.</summary>
public interface IAgentFactory
{
    /// <param name="toolsOverride">
    /// When set, builds the agent with exactly this tool set instead of all registered tools.
    /// Used by <see cref="Tools.TaskTool"/> to spawn sub-agents without including itself (would recurse).
    /// </param>
    AIAgent Create(IEnumerable<ITool>? toolsOverride = null);
}
