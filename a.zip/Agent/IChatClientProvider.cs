using Microsoft.Extensions.AI;

namespace CodeAgent.Agent;

/// <summary>Provider seam for the chat model, shaped around the framework's own abstraction
/// (<see cref="IChatClient"/>) instead of one SDK's concrete client — swapping providers means
/// swapping the implementation, not this contract.</summary>
public interface IChatClientProvider
{
    IChatClient GetChatClient(string model);
}
