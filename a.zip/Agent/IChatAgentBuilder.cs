using CodeAgent.Tools;
using Microsoft.Agents.AI;

namespace CodeAgent.Agent;

/// <summary>Builder pattern: constructs an <see cref="AIAgent"/> for an exact tool set. No knowledge of
/// which tools exist or how they're composed — that's <see cref="IAgentFactory"/>'s job. Kept separate so
/// <see cref="TaskTool"/> can build sub-agents without depending on <see cref="IAgentFactory"/>, which would
/// create a DI cycle (the default agent includes TaskTool, which would then depend on itself).</summary>
public interface IChatAgentBuilder
{
    AIAgent Build(IEnumerable<ITool> tools);
}
