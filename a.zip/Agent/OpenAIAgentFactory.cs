using CodeAgent.Tools;
using Microsoft.Agents.AI;

namespace CodeAgent.Agent;

public sealed class OpenAIAgentFactory : IAgentFactory
{
    private readonly IChatAgentBuilder _builder;
    private readonly IEnumerable<ITool> _defaultTools;

    /// <param name="workerTools">Read/Write/Edit/Bash/Grep/Glob/CodeSearch — everything except <see cref="TaskTool"/>.</param>
    /// <param name="taskTool">
    /// Registered separately from <paramref name="workerTools"/> (not as <see cref="ITool"/> in DI): it needs
    /// the worker tool list to build its sub-agents, so including it in that same list would be self-referential.
    /// </param>
    public OpenAIAgentFactory(IChatAgentBuilder builder, IEnumerable<ITool> workerTools, TaskTool taskTool)
    {
        _builder = builder;
        _defaultTools = workerTools.Append(taskTool);
    }

    public AIAgent Create(IEnumerable<ITool>? toolsOverride = null) =>
        _builder.Build(toolsOverride ?? _defaultTools);
}
