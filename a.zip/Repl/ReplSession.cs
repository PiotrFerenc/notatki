using CodeAgent.Agent;
using CodeAgent.Config;
using CodeAgent.Repl.Commands;
using CodeAgent.Session;
using CodeAgent.Ui;
using CodeAgent.Verification;
using Microsoft.Agents.AI;
using Microsoft.Extensions.Options;

namespace CodeAgent.Repl;

public sealed class ReplSession
{
    private readonly IAgentFactory _agentFactory;
    private readonly ISessionStore _sessionStore;
    private readonly IConsoleUi _ui;
    private readonly AgentOptions _options;
    private readonly SlashCommandRegistry _commands;
    private readonly TurnRenderer _renderer;
    private readonly IPersistentShell _shell;

    public ReplSession(
        IAgentFactory agentFactory,
        ISessionStore sessionStore,
        IConsoleUi ui,
        IOptions<AgentOptions> options,
        SlashCommandRegistry commands,
        TurnRenderer renderer,
        IPersistentShell shell)
    {
        _agentFactory = agentFactory;
        _sessionStore = sessionStore;
        _ui = ui;
        _options = options.Value;
        _commands = commands;
        _renderer = renderer;
        _shell = shell;
    }

    public async Task RunAsync(CancellationToken cancellationToken)
    {
        var agent = _agentFactory.Create();

        var savedState = await _sessionStore.LoadAsync(cancellationToken);
        var session = savedState is { } state
            ? await agent.DeserializeSessionAsync(state, cancellationToken: cancellationToken)
            : await agent.CreateSessionAsync(cancellationToken: cancellationToken);

        _ui.ShowBanner(model: _options.Model, cwd: Directory.GetCurrentDirectory(), resumedSession: savedState is not null);

        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                var replInput = ReplInput.Parse(_ui.ReadInput());
                if (replInput is ReplInput.ExitRequested)
                    break;

                var shouldExit = false;
                switch (replInput)
                {
                    case ReplInput.Empty:
                        break;

                    case ReplInput.Slash slash:
                    {
                        var effect = DispatchSlashCommand(slash.Name, slash.Argument);
                        switch (effect)
                        {
                            case SlashCommandEffect.Exit:
                                shouldExit = true;
                                break;
                            case SlashCommandEffect.ResetSession:
                                session = await agent.CreateSessionAsync(cancellationToken: cancellationToken);
                                _renderer.ResetHistoryWarning();
                                break;
                            case SlashCommandEffect.RebuildAgent:
                                agent = _agentFactory.Create();
                                break;
                        }

                        break;
                    }

                    case ReplInput.Shell shell:
                        await RunShellPassthroughAsync(shell.Command, cancellationToken);
                        break;

                    case ReplInput.Chat chat:
                        await RunTurnAsync(agent, session, chat.Text, cancellationToken);
                        break;
                }

                if (shouldExit)
                    break;
            }
        }
        finally
        {
            var serialized = await agent.SerializeSessionAsync(session, cancellationToken: CancellationToken.None);
            await _sessionStore.SaveAsync(serialized, CancellationToken.None);
        }
    }

    private SlashCommandEffect DispatchSlashCommand(string name, string argument)
    {
        if (!_commands.TryGet(name, out var command))
        {
            _ui.ShowError($"Nieznana komenda: /{name}. Wpisz /help.");
            return SlashCommandEffect.None;
        }

        return command.Execute(argument);
    }

    private async Task RunShellPassthroughAsync(string command, CancellationToken cancellationToken)
    {
        if (command.Length == 0)
        {
            _ui.ShowError("Podaj polecenie po !, np. !git status");
            return;
        }

        // Deliberately skips the permission gate, the dangerous-command denylist, and the workspace
        // sandbox: those exist to keep the *model* from taking unreviewed action, not to second-guess the
        // user's own direct input — they already have a real shell and could run anything anyway. Shares
        // the same PersistentShell as the Bash tool, so cd/env state is one session either way.
        _ui.ShowShellCommand(command);
        var result = await _shell.RunAsync(command, cancellationToken);
        _ui.WriteAssistantChunk(result.Output);
        _ui.EndAssistantTurn();

        if (result.ExitCode != 0)
            _ui.ShowError($"exit {result.ExitCode}");
    }

    private async Task RunTurnAsync(AIAgent agent, AgentSession session, string input, CancellationToken cancellationToken)
    {
        try
        {
            await using var enumerator = agent
                .RunStreamingAsync(input, session, cancellationToken: cancellationToken)
                .GetAsyncEnumerator(cancellationToken);

            var hasNext = await _ui.WithSpinnerAsync("Myślę…", () => enumerator.MoveNextAsync().AsTask());

            while (hasNext)
            {
                _renderer.Render(enumerator.Current);
                hasNext = await enumerator.MoveNextAsync();
            }

            _ui.EndAssistantTurn();
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            _ui.EndAssistantTurn();
            _ui.ShowInfo("Przerwano.");
        }
        catch (Exception ex)
        {
            // A network blip, a rate limit, a malformed streaming response — none of it should take the
            // whole REPL down. The session is still intact (it only records completed turns), so the user
            // just retries the message.
            _ui.EndAssistantTurn();
            _ui.ShowError($"Błąd podczas generowania odpowiedzi: {ex.Message}");
        }
    }
}
