namespace CodeAgent.Repl.Commands;

/// <summary>What <see cref="ReplSession"/> should do after a slash command runs. Commands declare intent
/// instead of mutating REPL state directly — keeps them simple and testable.</summary>
public enum SlashCommandEffect
{
    None,
    ResetSession,
    RebuildAgent,
    Exit,
}
