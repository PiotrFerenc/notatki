using CodeAgent.Ui;

namespace CodeAgent.Repl.Commands;

public sealed class ClearSlashCommand : ISlashCommand
{
    private readonly IConsoleUi _ui;

    public ClearSlashCommand(IConsoleUi ui)
    {
        _ui = ui;
    }

    public string Name => "clear";

    public string Description => "Wyczyść historię rozmowy i zacznij nową sesję";

    public SlashCommandEffect Execute(string argument)
    {
        _ui.ShowInfo("Sesja wyczyszczona.");
        return SlashCommandEffect.ResetSession;
    }
}
