using CodeAgent.Config;
using CodeAgent.Ui;
using Microsoft.Extensions.Options;

namespace CodeAgent.Repl.Commands;

public sealed class ConfigSlashCommand : ISlashCommand
{
    private readonly IOptions<AgentOptions> _options;
    private readonly IConsoleUi _ui;

    public ConfigSlashCommand(IOptions<AgentOptions> options, IConsoleUi ui)
    {
        _options = options;
        _ui = ui;
    }

    public string Name => "config";

    public string Description => "Pokaż aktualną konfigurację (model, base URL, zamaskowany klucz)";

    public SlashCommandEffect Execute(string argument)
    {
        _ui.ShowInfo(AgentOptionsFormatter.Format(_options.Value));
        return SlashCommandEffect.None;
    }
}
