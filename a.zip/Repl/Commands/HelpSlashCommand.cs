using CodeAgent.Ui;

namespace CodeAgent.Repl.Commands;

/// <summary>
/// Registered separately from the <see cref="ISlashCommand"/> DI collection (not added via
/// AddSingleton&lt;ISlashCommand,...&gt;) — same reason as <see cref="Tools.TaskTool"/>: it needs to list every
/// other command, and being part of the collection it enumerates would be a self-referential DI cycle.
/// </summary>
public sealed class HelpSlashCommand : ISlashCommand
{
    private readonly IEnumerable<ISlashCommand> _otherCommands;
    private readonly IConsoleUi _ui;

    public HelpSlashCommand(IEnumerable<ISlashCommand> otherCommands, IConsoleUi ui)
    {
        _otherCommands = otherCommands;
        _ui = ui;
    }

    public string Name => "help";

    public string Description => "Pokaż listę dostępnych komend";

    public SlashCommandEffect Execute(string argument)
    {
        var lines = _otherCommands
            .Append(this)
            .OrderBy(c => c.Name, StringComparer.OrdinalIgnoreCase)
            .Select(c => $"/{c.Name} — {c.Description}");

        _ui.ShowInfo(string.Join('\n', lines));
        return SlashCommandEffect.None;
    }
}
