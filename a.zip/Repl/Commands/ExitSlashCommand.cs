namespace CodeAgent.Repl.Commands;

public sealed class ExitSlashCommand : ISlashCommand
{
    public string Name => "exit";

    public string Description => "Zakończ program";

    public SlashCommandEffect Execute(string argument) => SlashCommandEffect.Exit;
}
