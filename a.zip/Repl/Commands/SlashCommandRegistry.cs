namespace CodeAgent.Repl.Commands;

/// <summary>Strategy dispatch by name. Composes the leaf commands (registered as <see cref="ISlashCommand"/>
/// in DI) with <see cref="HelpSlashCommand"/> (registered separately, see its own doc comment).</summary>
public sealed class SlashCommandRegistry
{
    private readonly IReadOnlyDictionary<string, ISlashCommand> _commands;

    public SlashCommandRegistry(IEnumerable<ISlashCommand> commands, HelpSlashCommand help)
    {
        _commands = commands.Append(help).ToDictionary(c => c.Name, StringComparer.OrdinalIgnoreCase);
    }

    public bool TryGet(string name, out ISlashCommand command) => _commands.TryGetValue(name, out command!);
}
