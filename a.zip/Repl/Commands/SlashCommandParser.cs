namespace CodeAgent.Repl.Commands;

/// <summary>Pure "/name argument" splitting, pulled out of <see cref="ReplSession"/> so it's testable
/// without standing up the whole REPL.</summary>
internal static class SlashCommandParser
{
    public static (string Name, string Argument) Parse(string trimmedInput)
    {
        var body = trimmedInput[1..];
        var spaceIndex = body.IndexOf(' ');
        var name = spaceIndex < 0 ? body : body[..spaceIndex];
        var argument = spaceIndex < 0 ? "" : body[(spaceIndex + 1)..].Trim();
        return (name, argument);
    }
}
