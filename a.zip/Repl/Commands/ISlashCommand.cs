namespace CodeAgent.Repl.Commands;

/// <summary>A built-in "/name" REPL command (Command pattern) — never sent to the model, handled entirely
/// client-side, same idea as Claude Code's slash commands.</summary>
public interface ISlashCommand
{
    /// <summary>Matched case-insensitively against the text right after "/", e.g. "model" for "/model gpt-5".</summary>
    string Name { get; }

    string Description { get; }

    SlashCommandEffect Execute(string argument);
}
