using CodeAgent.Config;
using CodeAgent.Ui;
using Microsoft.Extensions.Options;

namespace CodeAgent.Repl.Commands;

/// <summary>Views or swaps the model for the rest of this run. Mutates the shared <see cref="AgentOptions"/>
/// instance in place — <see cref="Agent.ChatAgentBuilder"/> reads it fresh on every rebuild, so a
/// <see cref="SlashCommandEffect.RebuildAgent"/> afterward is enough to make it take effect.</summary>
public sealed class ModelSlashCommand : ISlashCommand
{
    private readonly IOptions<AgentOptions> _options;
    private readonly IConsoleUi _ui;

    public ModelSlashCommand(IOptions<AgentOptions> options, IConsoleUi ui)
    {
        _options = options;
        _ui = ui;
    }

    public string Name => "model";

    public string Description => "Pokaż lub zmień model na czas tej sesji: /model gpt-4.1";

    public SlashCommandEffect Execute(string argument)
    {
        if (string.IsNullOrWhiteSpace(argument))
        {
            _ui.ShowInfo($"Aktualny model: {_options.Value.Model}");
            return SlashCommandEffect.None;
        }

        _options.Value.Model = argument.Trim();
        _ui.ShowInfo($"Model zmieniony na: {_options.Value.Model}");
        return SlashCommandEffect.RebuildAgent;
    }
}
