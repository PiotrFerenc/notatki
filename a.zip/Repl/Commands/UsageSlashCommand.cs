using CodeAgent.Diagnostics;
using CodeAgent.Ui;

namespace CodeAgent.Repl.Commands;

public sealed class UsageSlashCommand : ISlashCommand
{
    private readonly IUsageTracker _tracker;
    private readonly IConsoleUi _ui;

    public UsageSlashCommand(IUsageTracker tracker, IConsoleUi ui)
    {
        _tracker = tracker;
        _ui = ui;
    }

    public string Name => "usage";

    public string Description => "Pokaż zużycie tokenów w tej sesji";

    public SlashCommandEffect Execute(string argument)
    {
        var total = _tracker.Total;
        _ui.ShowInfo(
            $"Input:  {total.InputTokenCount ?? 0}\n" +
            $"Output: {total.OutputTokenCount ?? 0}\n" +
            $"Razem:  {total.TotalTokenCount ?? 0}");
        return SlashCommandEffect.None;
    }
}
