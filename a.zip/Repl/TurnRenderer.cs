using CodeAgent.Diagnostics;
using CodeAgent.Tools;
using CodeAgent.Ui;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

namespace CodeAgent.Repl;

/// <summary>
/// Turns a streamed <see cref="AgentResponseUpdate"/> into UI calls (tool-call bullets, result lines,
/// assistant text) and tracks usage/history-size as a side effect. Split out of <see cref="ReplSession"/>,
/// which was accumulating REPL-loop control flow, slash dispatch, and rendering all in one place.
/// </summary>
public sealed class TurnRenderer
{
    // Not real compaction — the framework doesn't expose the session's message list for external
    // truncation/summarization, only opaque serialize/deserialize. This is the honest version: a one-time
    // heads-up once a turn's input is large enough that a context-window failure is plausible, so the user
    // can /clear before hitting it instead of just after (caught gracefully either way by RunTurnAsync's
    // catch, but a warning beats a surprise).
    private const long HistoryWarningInputTokens = 50_000;

    private readonly IConsoleUi _ui;
    private readonly IUsageTracker _usage;
    private bool _historyWarningShown;

    public TurnRenderer(IConsoleUi ui, IUsageTracker usage)
    {
        _ui = ui;
        _usage = usage;
    }

    /// <summary>Call when starting a fresh conversation (e.g. /clear) — a smaller history no longer
    /// warrants the earlier warning.</summary>
    public void ResetHistoryWarning() => _historyWarningShown = false;

    public void Render(AgentResponseUpdate update)
    {
        foreach (var content in update.Contents)
        {
            switch (content)
            {
                case FunctionCallContent call:
                    _ui.ShowToolCall(call.Name, ToolArgumentFormatter.Summarize(call.Arguments!));
                    break;
                case FunctionResultContent result:
                    _ui.ShowToolResult(ToolArgumentFormatter.Truncate(result.Result));
                    break;
                case UsageContent usage:
                    _usage.Add(usage.Details);
                    CheckHistorySize(usage.Details);
                    break;
            }
        }

        if (!string.IsNullOrEmpty(update.Text))
            _ui.WriteAssistantChunk(update.Text);
    }

    private void CheckHistorySize(UsageDetails? usage)
    {
        if (_historyWarningShown || usage?.InputTokenCount is not { } inputTokens)
            return;

        if (inputTokens < HistoryWarningInputTokens)
            return;

        _historyWarningShown = true;
        _ui.ShowInfo($"Historia rozmowy urosła (~{inputTokens:N0} tokenów wejściowych). " +
                      "Rozważ /clear, jeśli nie potrzebujesz starszego kontekstu.");
    }
}
