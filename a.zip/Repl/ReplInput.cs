using CodeAgent.Repl.Commands;

namespace CodeAgent.Repl;

/// <summary>
/// What the user typed at the prompt, classified. Turns the old "if starts with /, else if starts with !,
/// else if it's exit/quit, else it's chat" chain into a single pure function returning a typed value —
/// parsing (this file) is now fully separate from execution (the switch in <see cref="ReplSession"/>), and
/// <see cref="Parse"/> is trivial to unit test on its own.
/// </summary>
public abstract record ReplInput
{
    private ReplInput()
    {
    }

    public sealed record Empty : ReplInput;

    public sealed record ExitRequested : ReplInput;

    public sealed record Slash(string Name, string Argument) : ReplInput;

    public sealed record Shell(string Command) : ReplInput;

    public sealed record Chat(string Text) : ReplInput;

    /// <param name="rawInput">Whatever <see cref="Ui.IConsoleUi.ReadInput"/> returned — null means EOF
    /// (piped stdin ran out, or Ctrl+D), which is treated the same as typing "exit".</param>
    public static ReplInput Parse(string? rawInput)
    {
        if (rawInput is null)
            return new ExitRequested();

        var trimmed = rawInput.Trim();

        return trimmed switch
        {
            "" => new Empty(),
            "exit" or "quit" => new ExitRequested(),
            _ when trimmed.StartsWith('/') => ParseSlash(trimmed),
            _ when trimmed.StartsWith('!') => new Shell(trimmed[1..].Trim()),
            _ => new Chat(trimmed),
        };
    }

    private static Slash ParseSlash(string trimmed)
    {
        var (name, argument) = SlashCommandParser.Parse(trimmed);
        return new Slash(name, argument);
    }
}
