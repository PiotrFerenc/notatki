using System.Text.Json;

namespace CodeAgent.Session;

/// <summary>Stores the session as JSON under .codeagent/session.json in the current directory.</summary>
public sealed class FileSessionStore : ISessionStore
{
    private static readonly string FilePath =
        Path.Combine(Directory.GetCurrentDirectory(), ".codeagent", "session.json");

    public async Task<JsonElement?> LoadAsync(CancellationToken cancellationToken)
    {
        if (!File.Exists(FilePath))
            return null;

        await using var stream = File.OpenRead(FilePath);
        var document = await JsonDocument.ParseAsync(stream, cancellationToken: cancellationToken);
        return document.RootElement.Clone();
    }

    public async Task SaveAsync(JsonElement state, CancellationToken cancellationToken)
    {
        var dir = Path.GetDirectoryName(FilePath)!;
        Directory.CreateDirectory(dir);

        await using var stream = File.Create(FilePath);
        await JsonSerializer.SerializeAsync(stream, state, cancellationToken: cancellationToken);
    }
}
