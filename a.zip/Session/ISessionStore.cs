using System.Text.Json;

namespace CodeAgent.Session;

/// <summary>Repository pattern: persists the serialized agent session (conversation state) across runs.</summary>
public interface ISessionStore
{
    Task<JsonElement?> LoadAsync(CancellationToken cancellationToken);

    Task SaveAsync(JsonElement state, CancellationToken cancellationToken);
}
