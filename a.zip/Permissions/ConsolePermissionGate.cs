using CodeAgent.Ui;

namespace CodeAgent.Permissions;

public sealed class ConsolePermissionGate : IPermissionGate
{
    private readonly IConsoleUi _ui;

    // Process-lifetime, not conversation-lifetime: a "yes, always" is a trust decision about running Bash /
    // touching files in this environment, not about the conversation content, so /clear doesn't reset it.
    private readonly HashSet<string> _alwaysAllowed = new(StringComparer.Ordinal);

    public ConsolePermissionGate(IConsoleUi ui)
    {
        _ui = ui;
    }

    public Task<bool> ConfirmAsync(string toolName, string argsSummary, CancellationToken cancellationToken)
    {
        if (_alwaysAllowed.Contains(toolName))
            return Task.FromResult(true);

        var result = _ui.Confirm(toolName, argsSummary);
        if (result == ConfirmResult.AlwaysAllow)
            _alwaysAllowed.Add(toolName);

        return Task.FromResult(result != ConfirmResult.Deny);
    }
}
