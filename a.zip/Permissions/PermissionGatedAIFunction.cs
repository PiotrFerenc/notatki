using CodeAgent.Tools;
using Microsoft.Extensions.AI;

namespace CodeAgent.Permissions;

/// <summary>Decorator: gates an <see cref="AIFunction"/> behind <see cref="IPermissionGate"/> before invoking it.</summary>
public sealed class PermissionGatedAIFunction : DelegatingAIFunction
{
    private readonly IPermissionGate _gate;
    private readonly ITool _tool;

    public PermissionGatedAIFunction(AIFunction inner, IPermissionGate gate, ITool tool) : base(inner)
    {
        _gate = gate;
        _tool = tool;
    }

    protected override async ValueTask<object?> InvokeCoreAsync(
        AIFunctionArguments arguments, CancellationToken cancellationToken)
    {
        var argsSummary = _tool.FormatConfirmation(arguments!) ?? ToolArgumentFormatter.Summarize(arguments!);
        if (!await _gate.ConfirmAsync(Name, argsSummary, cancellationToken))
            return "User denied permission for this action.";

        return await base.InvokeCoreAsync(arguments, cancellationToken);
    }
}
