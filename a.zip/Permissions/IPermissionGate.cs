namespace CodeAgent.Permissions;

/// <summary>Strategy for approving a mutating tool call before it runs.</summary>
public interface IPermissionGate
{
    Task<bool> ConfirmAsync(string toolName, string argsSummary, CancellationToken cancellationToken);
}
