namespace CodeAgent.Config;

public sealed class AgentOptions
{
    public const string SectionName = "Agent";

    public string ApiKey { get; set; } = "";

    public string Model { get; set; } = "gpt-5";

    /// Nazwa modelu embeddingu używanego do generowania wektorów osadzeń dla wyszukiwania semantycznego.
    public string EmbeddingModel { get; set; } = "text-embedding-3-small";

    public string? BaseUrl { get; set; }

    /// <summary>Hard cap on tool calls the model can make within a single turn. The framework default is
    /// 40; lower here on purpose so a runaway loop (e.g. a repeatedly-failing Edit) burns less before
    /// stopping.</summary>
    public int MaxToolIterationsPerTurn { get; set; } = 20;

    public int BashTimeoutSeconds { get; set; } = 120;
}
