namespace CodeAgent.Config;

/// <summary>Renders effective config for display — used by `--show-config` and the `/config` slash command.
/// Never includes the raw API key.</summary>
public static class AgentOptionsFormatter
{
    public static string Format(AgentOptions options)
    {
        var maskedKey = string.IsNullOrEmpty(options.ApiKey)
            ? "(brak)"
            : $"{options.ApiKey[..Math.Min(7, options.ApiKey.Length)]}… ({options.ApiKey.Length} znaków)";

        return $"""
            Model:                    {options.Model}
            EmbeddingModel:           {options.EmbeddingModel}
            BaseUrl:                  {options.BaseUrl ?? "(domyślny OpenAI)"}
            ApiKey:                   {maskedKey}
            MaxToolIterationsPerTurn: {options.MaxToolIterationsPerTurn}
            BashTimeoutSeconds:       {options.BashTimeoutSeconds}
            """;
    }
}
