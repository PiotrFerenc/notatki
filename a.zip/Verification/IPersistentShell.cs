namespace CodeAgent.Verification;

/// <summary>
/// A single long-lived shell the agent's Bash tool talks to across the whole run — like a real terminal,
/// not a fresh process per command. <c>cd</c>, exported env vars, shell functions, background jobs started
/// with <c>&amp;</c> — all persist from one call to the next, matching how Claude Code's own Bash tool
/// behaves. Split from <see cref="IBashRunner"/> (the one-shot runner used for auto-build-verification)
/// specifically so that verification stays deterministic even if the agent has `cd`'d somewhere odd.
/// </summary>
public interface IPersistentShell
{
    Task<BashResult> RunAsync(string command, CancellationToken cancellationToken);
}
