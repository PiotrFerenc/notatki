using Microsoft.Extensions.AI;

namespace CodeAgent.Verification;

public sealed class BuildVerifier : IBuildVerifier
{
    private readonly IProjectCommandDetector _detector;
    private readonly IBashRunner _bashRunner;

    public BuildVerifier(IProjectCommandDetector detector, IBashRunner bashRunner)
    {
        _detector = detector;
        _bashRunner = bashRunner;
    }

    public AIFunction Wrap(AIFunction inner) => new BuildVerifyingAIFunction(inner, _detector, _bashRunner);
}
