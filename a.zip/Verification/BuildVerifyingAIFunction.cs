using Microsoft.Extensions.AI;

namespace CodeAgent.Verification;

/// <summary>
/// Decorator: after the wrapped tool succeeds, auto-runs the repo's detected build command and appends a
/// pass/fail report to the result. ponytail: runs on every single Write/Edit call, not just at the end of a
/// task — simplest way to guarantee it never gets skipped, at the cost of a rebuild per edit. Fine for small
/// repos; if that gets slow on a big one, debounce to "once per turn" instead of per-call.
/// </summary>
public sealed class BuildVerifyingAIFunction : DelegatingAIFunction
{
    private const int MaxOutputLength = 2000;

    private readonly IProjectCommandDetector _detector;
    private readonly IBashRunner _bashRunner;

    public BuildVerifyingAIFunction(AIFunction inner, IProjectCommandDetector detector, IBashRunner bashRunner)
        : base(inner)
    {
        _detector = detector;
        _bashRunner = bashRunner;
    }

    protected override async ValueTask<object?> InvokeCoreAsync(
        AIFunctionArguments arguments, CancellationToken cancellationToken)
    {
        var result = await base.InvokeCoreAsync(arguments, cancellationToken);

        var commands = _detector.Detect(Directory.GetCurrentDirectory());
        if (commands.Build is null)
            return result;

        var build = await _bashRunner.RunAsync(commands.Build, cancellationToken);
        var verdict = build.ExitCode == 0 ? "OK" : "FAILED";
        var output = build.Output.Length > MaxOutputLength ? build.Output[..MaxOutputLength] + "…" : build.Output;

        return $"{result}\n\n[auto-verify: {commands.Build} → {verdict}]\n{output}";
    }
}
