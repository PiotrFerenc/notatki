using System.Collections.Concurrent;
using System.Text.Json;

namespace CodeAgent.Verification;

public sealed class ProjectCommandDetector : IProjectCommandDetector
{
    private readonly ConcurrentDictionary<string, ProjectCommands> _cache = new();

    public ProjectCommands Detect(string root) => _cache.GetOrAdd(root, DetectCore);

    private static ProjectCommands DetectCore(string root)
    {
        if (Directory.EnumerateFiles(root, "*.sln", SearchOption.TopDirectoryOnly).Any() ||
            Directory.EnumerateFiles(root, "*.csproj", SearchOption.AllDirectories).Any())
            return new ProjectCommands("dotnet build", "dotnet test");

        var packageJson = Path.Combine(root, "package.json");
        if (File.Exists(packageJson))
            return DetectFromPackageJson(packageJson);

        var makefile = Path.Combine(root, "Makefile");
        if (File.Exists(makefile))
            return DetectFromMakefile(makefile);

        if (File.Exists(Path.Combine(root, "pyproject.toml")) || File.Exists(Path.Combine(root, "requirements.txt")))
            return new ProjectCommands(Build: null, Test: "pytest");

        return new ProjectCommands(Build: null, Test: null);
    }

    private static ProjectCommands DetectFromPackageJson(string path)
    {
        try
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(path));
            var hasScripts = doc.RootElement.TryGetProperty("scripts", out var scripts)
                && scripts.ValueKind == JsonValueKind.Object;

            var build = hasScripts && scripts.TryGetProperty("build", out _) ? "npm run build" : null;
            var test = hasScripts && scripts.TryGetProperty("test", out _) ? "npm test" : null;
            return new ProjectCommands(build, test);
        }
        catch (JsonException)
        {
            return new ProjectCommands(Build: null, Test: null);
        }
    }

    private static ProjectCommands DetectFromMakefile(string path)
    {
        var lines = File.ReadAllLines(path);
        var build = lines.Any(l => l.StartsWith("build:", StringComparison.Ordinal)) ? "make build" : null;
        var test = lines.Any(l => l.StartsWith("test:", StringComparison.Ordinal)) ? "make test" : null;
        return new ProjectCommands(build, test);
    }
}
