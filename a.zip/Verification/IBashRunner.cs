namespace CodeAgent.Verification;

public readonly record struct BashResult(int ExitCode, string Output);

/// <summary>One-shot /bin/sh process runner, always from the workspace root — used by
/// <see cref="BuildVerifyingAIFunction"/> so auto-verification is deterministic regardless of where the
/// agent's own <see cref="Workspace.IWorkspaceGuard"/>-adjacent <c>Bash</c> tool has `cd`'d to. The agent's
/// interactive shell is <see cref="IPersistentShell"/> instead — see its doc comment for why they're split.</summary>
public interface IBashRunner
{
    Task<BashResult> RunAsync(string command, CancellationToken cancellationToken);
}
