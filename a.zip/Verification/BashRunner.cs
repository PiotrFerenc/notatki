using System.Diagnostics;
using CodeAgent.Config;
using CodeAgent.Workspace;
using Microsoft.Extensions.Options;

namespace CodeAgent.Verification;

public sealed class BashRunner : IBashRunner
{
    private readonly IWorkspaceGuard _workspace;
    private readonly TimeSpan _timeout;

    public BashRunner(IWorkspaceGuard workspace, IOptions<AgentOptions> options)
    {
        _workspace = workspace;
        _timeout = TimeSpan.FromSeconds(options.Value.BashTimeoutSeconds);
    }

    public async Task<BashResult> RunAsync(string command, CancellationToken cancellationToken)
    {
        var psi = new ProcessStartInfo("/bin/sh")
        {
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            // Relative-path commands stay rooted here. Not real sandboxing — a command using an
            // absolute path (or "cd /") still escapes. See DangerousCommandPatterns for the other half.
            WorkingDirectory = _workspace.Root,
        };
        psi.ArgumentList.Add("-c");
        psi.ArgumentList.Add(command);

        using var process = Process.Start(psi)
            ?? throw new InvalidOperationException("Failed to start /bin/sh");

        using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        cts.CancelAfter(_timeout);

        var stdoutTask = process.StandardOutput.ReadToEndAsync(cts.Token);
        var stderrTask = process.StandardError.ReadToEndAsync(cts.Token);

        try
        {
            await process.WaitForExitAsync(cts.Token);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            process.Kill(entireProcessTree: true);
            return new BashResult(-1, $"Error: command timed out after {_timeout.TotalSeconds:N0}s");
        }

        var stdout = await stdoutTask;
        var stderr = await stderrTask;
        return new BashResult(process.ExitCode, stdout + stderr);
    }
}
