using System.Diagnostics;
using System.Text;
using CodeAgent.Config;
using CodeAgent.Workspace;
using Microsoft.Extensions.Options;

namespace CodeAgent.Verification;

/// <summary>
/// One <c>/bin/bash</c> process kept alive for the run, driven over its stdin/stdout pipes. Each call writes
/// the command followed by a `printf` that emits a unique marker + exit code, then reads stdout lines until
/// that marker shows up — the standard trick for turning an interactive shell into a request/response API.
/// stderr is merged into stdout once, at startup (`exec 2>&1`), so only one stream needs draining.
/// </summary>
public sealed class PersistentShell : IPersistentShell, IDisposable
{
    private readonly string _marker = "__CODEAGENT_DONE_" + Guid.NewGuid().ToString("N") + "__";
    private readonly IWorkspaceGuard _workspace;
    private readonly TimeSpan _timeout;
    private readonly SemaphoreSlim _lock = new(1, 1);

    private Process? _process;

    public PersistentShell(IWorkspaceGuard workspace, IOptions<AgentOptions> options)
    {
        _workspace = workspace;
        _timeout = TimeSpan.FromSeconds(options.Value.BashTimeoutSeconds);
    }

    public async Task<BashResult> RunAsync(string command, CancellationToken cancellationToken)
    {
        await _lock.WaitAsync(cancellationToken);
        try
        {
            EnsureStarted();
            var process = _process!;

            await process.StandardInput.WriteLineAsync(command);
            // $? must be read by the very next statement in the same shell, so this line has to follow
            // the command with nothing in between — which sending it as the next stdin line guarantees.
            await process.StandardInput.WriteLineAsync($"printf '\\n{_marker}:%d\\n' \"$?\"");

            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(_timeout);

            var output = new StringBuilder();
            try
            {
                while (true)
                {
                    var line = await process.StandardOutput.ReadLineAsync(cts.Token);
                    if (line is null)
                    {
                        RestartShell();
                        return new BashResult(-1, output + "\nError: shell exited unexpectedly, session restarted");
                    }

                    if (line.StartsWith(_marker, StringComparison.Ordinal))
                    {
                        var exitCode = int.TryParse(line.AsSpan(_marker.Length + 1), out var code) ? code : -1;
                        return new BashResult(exitCode, output.ToString());
                    }

                    output.AppendLine(line);
                }
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
            {
                // Can't interrupt just the stuck command without real job control, and leaving the shell
                // half-fed a command would corrupt every call after it — restart clean instead.
                RestartShell();
                return new BashResult(-1, $"Error: command timed out after {_timeout.TotalSeconds:N0}s, shell session restarted (cwd/env from before the timeout are lost)");
            }
        }
        finally
        {
            _lock.Release();
        }
    }

    private void EnsureStarted()
    {
        if (_process is { HasExited: false })
            return;

        _process?.Dispose();

        var psi = new ProcessStartInfo("/bin/bash")
        {
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            WorkingDirectory = _workspace.Root,
        };

        _process = Process.Start(psi) ?? throw new InvalidOperationException("Failed to start persistent shell");
        _process.StandardInput.AutoFlush = true;
        _process.StandardInput.WriteLine("exec 2>&1");
    }

    private void RestartShell()
    {
        try
        {
            _process?.Kill(entireProcessTree: true);
        }
        catch (InvalidOperationException)
        {
            // already exited
        }

        _process?.Dispose();
        _process = null;
    }

    public void Dispose()
    {
        RestartShell();
        _lock.Dispose();
    }
}
