namespace CodeAgent.Verification;

public sealed record ProjectCommands(string? Build, string? Test);

/// <summary>Figures out how to build/test this repo once (per root), so the agent and the auto-verify
/// decorator don't have to guess "dotnet build" vs "npm run build" vs "make" every time.</summary>
public interface IProjectCommandDetector
{
    ProjectCommands Detect(string root);
}
