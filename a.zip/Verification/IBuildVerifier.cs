using Microsoft.Extensions.AI;

namespace CodeAgent.Verification;

/// <summary>Wraps a mutating tool's <see cref="AIFunction"/> so its result carries a build-verification
/// report — the agent can't get a "Wrote file" result without also learning whether it still compiles.</summary>
public interface IBuildVerifier
{
    AIFunction Wrap(AIFunction inner);
}
