# CodeAgent

Agent kodujący uruchamiany lokalnie w terminalu, w stylu Claude Code — zbudowany na Microsoft Agent Framework, z modelami OpenAI jako silnikiem LLM. Docelowy stack: **.NET 10**, **C#**, **Spectre.Console** (UI terminalowe).

---

## 1. Dokumentacja biznesowa

### Jaki problem to rozwiązuje

Zespoły programistyczne coraz częściej chcą agenta LLM działającego bezpośrednio na repozytorium — czytającego kod, edytującego pliki, uruchamiającego build/testy, bez opuszczania terminala. Gotowe produkty (Claude Code, Cursor, itp.) robią to jako zamknięte SaaS. CodeAgent to **własna, w pełni kontrolowana implementacja** tego samego wzorca interakcji, z otwartym stackiem (Microsoft Agent Framework) i dowolnym kluczem OpenAI — bez zależności od konkretnego dostawcy narzędzia.

### Dla kogo

Dla zespołu/dewelopera, który chce:
- mieć pełną kontrolę nad tym, jakie narzędzia agent ma i jak się zachowuje (system prompt, limity, sandbox),
- trzymać kod i konfigurację we własnym repozytorium, bez wysyłania danych do zewnętrznego produktu agentowego,
- móc rozszerzać agenta o własne narzędzia/komendy bez czekania na dostawcę.

### Co odróżnia CodeAgent od "zwykłego chatbota z narzędziami"

| Cecha | Dlaczego to ważne biznesowo |
|---|---|
| **Permission gate** (y/n/a) na każdej akcji zapisu/wykonania | Człowiek zawsze zatwierdza ryzykowne działania — agent nie może np. skasować plików bez zgody. |
| **Automatyczna weryfikacja builda** po każdej zmianie kodu | Agent nie może "zgłosić sukcesu" zmiany, która nie kompiluje się — feedback jest wymuszony strukturalnie, nie tylko sugerowany w promptcie. |
| **Sandbox katalogu roboczego** | Agent fizycznie nie jest w stanie odczytać/nadpisać plików spoza repozytorium (np. kluczy SSH), nawet przez pomyłkę. |
| **Trwała sesja rozmowy i powłoki** | Można przerwać pracę i wrócić do niej później — kontekst rozmowy i stan terminala (cd, zmienne env) przeżywają restart programu / kolejne wywołania. |
| **Denylist niebezpiecznych komend** | Twardy blok na `rm -rf /`, `sudo`, fork-bomby itp. — niezależnie od tego, czy człowiek machinalnie kliknie "tak". |
| **Widoczny koszt** (`/usage`) | Wiadomo, ile tokenów/pieniędzy zużywa sesja — nie jest to czarna skrzynka. |

### Ryzyka i świadome ograniczenia (ważne do zakomunikowania interesariuszom)

- To **nie jest** sandbox na poziomie systemu operacyjnego (kontener/VM). Agent działa z uprawnieniami użytkownika, który uruchomił program. Ochrony (workspace guard, denylist) są warstwą defensywną, nie twierdzą nie do zdobycia.
- Model może w pojedynczej turze wykonać kilkanaście wywołań narzędzi (limit konfigurowalny) — realny koszt API rośnie z każdym takim wywołaniem.
- Nie ma mechanizmu "co dokładnie zmienił agent w tym tygodniu" poza logiem plikowym i historią sesji — to narzędzie deweloperskie, nie system audytowy klasy enterprise.

---

## 2. Szybki start

```bash
# wymagania: .NET 10 SDK, klucz OpenAI

# klucz API — nigdy nie trafia do appsettings.json (to plik commitowany)
echo 'OPENAI_API_KEY=sk-...' > .env.local

dotnet build
dotnet run
```

Weryfikacja bez klucza / bez sieci:
```bash
dotnet run -- --self-test    # ~20 grup asercji, logika narzędzi i mechanizmów bezpieczeństwa
dotnet run -- --show-config  # pokazuje efektywną konfigurację (klucz zamaskowany)
```

---

## 3. Architektura techniczna

### 3.1 Warstwy

```
Program.cs (DI, wejście)
        │
   Repl/           ← pętla interakcji z użytkownikiem (REPL)
        │
   Agent/           ← budowa instancji agenta LLM (Microsoft Agent Framework + OpenAI)
        │
   Tools/           ← narzędzia wołane przez model (Read/Write/Edit/Bash/Grep/Glob/CodeSearch/Plan/Task)
        │
   Permissions/ Verification/ Workspace/   ← warstwy ochronne owijające narzędzia
        │
   Search/ Session/ Diagnostics/ Config/ Ui/   ← usługi pomocnicze
```

Każda warstwa zna tylko warstwy pod sobą — `Tools` nie wie nic o `Repl`, `Agent` nie wie nic o `Ui`. Cała spójność spinana jest przez DI w `Program.cs`.

### 3.2 Wzorce projektowe — gdzie i po co

| Wzorzec | Gdzie | Po co |
|---|---|---|
| **Command** | `ITool` (Read/Write/Edit/Bash/...), `ISlashCommand` (/help, /clear...) | Każde narzędzie/komenda to samodzielny obiekt z jednolitym kontraktem — dodanie nowego narzędzia nie rusza istniejących. |
| **Strategy** | `IPermissionGate`, `IWorkspaceGuard`, `IProjectCommandDetector` | Wymienne reguły decyzyjne (czy pozwolić, czy ścieżka bezpieczna, jaka komenda build) bez `if`-drzew w kodzie wywołującym. |
| **Decorator** | `PermissionGatedAIFunction`, `BuildVerifyingAIFunction` | Owijają `AIFunction` frameworku — dokładają potwierdzenie / auto-weryfikację builda, nie zmieniając samego narzędzia. Składają się w łańcuch (`ToolFunctionAdapter`). |
| **Adapter** | `ToolFunctionAdapter` | Tłumaczy nasz `ITool` (framework-agnostyczny) na `AITool` wymagany przez Microsoft Agent Framework. |
| **Builder** | `IChatAgentBuilder`/`ChatAgentBuilder` | Składa gotową instancję agenta (klient, narzędzia, system prompt, limity) — używane i dla głównego agenta, i dla sub-agentów `Task`. |
| **Factory** | `IAgentFactory`/`OpenAIAgentFactory` | Decyduje, jaki *zestaw* narzędzi dostaje agent (domyślny vs. nadpisany dla subagenta), deleguje budowę do Buildera. |
| **Facade** | `IConsoleUi`/`SpectreConsoleUi` | Cała prezentacja terminalowa (panele, kolory, spinner) za jednym interfejsem — `ReplSession` nigdy nie dotyka `Console` bezpośrednio. |
| **Interpreter / typed parse** | `ReplInput` | Zamienia surowy string z promptu na typowany wariant (`Chat`/`Slash`/`Shell`/`Exit`/`Empty`) jedną czystą funkcją — reszta kodu robi `switch`, nie `StartsWith`-y. |

### 3.3 Powtarzający się wzorzec: "split DI, żeby uniknąć cyklu"

`TaskTool` (deleguje pracę do subagenta) potrzebuje listy *pozostałych* narzędzi, żeby zbudować subagenta — ale gdyby sam był w tej liście, DI próbowałby skonstruować go w nieskończoność. Rozwiązanie: `TaskTool` rejestrowany jest **osobno**, nie w kolekcji `ITool`; `OpenAIAgentFactory` dokleja go do listy dopiero przy budowie *domyślnego* zestawu. Dokładnie ten sam trik zastosowany jest w `Repl/Commands` dla `HelpSlashCommand` (potrzebuje listy wszystkich komend, żeby je wypisać, więc też nie jest częścią kolekcji `ISlashCommand`).

### 3.4 Diagram przepływu — co się dzieje po Enterze

```mermaid
flowchart TD
    Start(["Użytkownik wpisuje linię w promptcie"]) --> Parse{"ReplInput.Parse"}

    Parse -->|puste| Start
    Parse -->|"exit / quit / EOF"| Save["Zapis sesji (finally) i wyjście"]
    Parse -->|"/nazwa argument"| SlashLookup{"SlashCommandRegistry.TryGet"}
    Parse -->|"!polecenie"| ShellRun["IPersistentShell.RunAsync<br/>(bez LLM, bez permission-gate)"]
    Parse -->|zwykły tekst| Chat["AIAgent.RunStreamingAsync"]

    SlashLookup -->|nieznana| Unknown["ShowError"] --> Start
    SlashLookup -->|znana| Exec["ISlashCommand.Execute"] --> Effect{"SlashCommandEffect"}
    Effect -->|None| Start
    Effect -->|Exit| Save
    Effect -->|ResetSession| Reset["Nowa AgentSession +<br/>TurnRenderer.ResetHistoryWarning"] --> Start
    Effect -->|RebuildAgent| Rebuild["IAgentFactory.Create() ponownie<br/>(np. po /model)"] --> Start

    ShellRun --> ShellOut["Wynik na ekran"] --> Start

    Chat --> Decide{"Model: tekst czy tool-call?"}
    Decide -->|"tekst / limit MaxToolIterationsPerTurn"| Render["TurnRenderer.Render →<br/>WriteAssistantChunk"] --> Start

    Decide -->|tool-call| Adapter["ToolFunctionAdapter:<br/>łańcuch dekoratorów"]
    Adapter --> BuildCheck{"VerifyBuildAfterInvoke?"}
    BuildCheck -->|tak| BuildWrap["BuildVerifyingAIFunction owija"] --> ConfirmCheck
    BuildCheck -->|nie| ConfirmCheck{"RequiresConfirmation?"}
    ConfirmCheck -->|tak| Gate["IPermissionGate.ConfirmAsync<br/>(panel y/n/a)"]
    Gate -->|Deny| Decide
    Gate -->|"Allow / AlwaysAllow"| RunTool
    ConfirmCheck -->|nie| RunTool["Wykonanie narzędzia"]
    RunTool --> Guards["IWorkspaceGuard / IFileReadTracker /<br/>FileContentGuard / DangerousCommandPatterns<br/>(wewnątrz konkretnego narzędzia)"]
    Guards --> AutoVerify["Auto-build-verify, jeśli był owinięty"]
    AutoVerify --> Decide

    Save --> End(["koniec procesu"])
```

Kluczowe: pętla `Decide → tool-call → ... → Decide` to jedna tura (`RunTurnAsync`) — model może w niej wywołać narzędzie wielokrotnie, aż sam zdecyduje że ma tekst do zwrócenia albo padnie `MaxToolIterationsPerTurn`. Ścieżki `/` i `!` nigdy tam nie wchodzą — są rozstrzygane w pętli REPL, zanim cokolwiek trafi do modelu.

---

## 4. Komponenty — kto za co odpowiada

### `Program.cs` — kompozycja aplikacji
Rejestruje wszystkie serwisy w DI, ładuje `.env.local` (patrz `Config`), obsługuje flagi `--self-test`/`--show-config`, podpina Ctrl+C pod `CancellationToken`, uruchamia `ReplSession`.

### `Agent/` — budowa agenta LLM

| Plik | Odpowiedzialność |
|---|---|
| `IAgentFactory` / `OpenAIAgentFactory` | Składa domyślny zestaw narzędzi (worker tools + `TaskTool`) i deleguje budowę do `IChatAgentBuilder`. Jedyne miejsce, które zna "pełną" listę narzędzi agenta. |
| `IChatAgentBuilder` / `ChatAgentBuilder` | Tworzy konkretną instancję `AIAgent`: klient OpenAI, system prompt (dopasowany do wykrytych komend build/test repo), limit iteracji narzędzi (`MaximumIterationsPerRequest`), logowanie do pliku. |
| `IChatClientProvider` / `IEmbeddingClientProvider` / `OpenAIClientProvider` | Jeden `OpenAIClient` (klucz, endpoint) reużywany przez chat (`IChatClient`) i embeddingi — żeby nie budować klienta dwa razy. |
| `SystemPrompt` | Generuje instrukcje systemowe dynamicznie — treść zależy od wykrytej komendy build/test repozytorium (patrz `Verification/IProjectCommandDetector`). |

### `Tools/` — narzędzia dostępne dla modelu

| Narzędzie | Co robi | Wymaga potwierdzenia? |
|---|---|---|
| `ReadTool` | Czyta plik z numeracją linii. Blokuje pliki binarne/za duże (`FileContentGuard`) i spoza workspace. | Nie |
| `WriteTool` | Tworzy/nadpisuje plik. Wymaga wcześniejszego `Read`, jeśli plik już istnieje. | Tak |
| `EditTool` | Podmienia dokładny, unikalny fragment tekstu w pliku. Wymaga wcześniejszego `Read`. Generuje diff (`-`/`+`) do panelu potwierdzenia. | Tak |
| `BashTool` | Uruchamia komendę w trwałej sesji powłoki (`IPersistentShell`) — `cd`/`export` przeżywają kolejne wywołania. Blokuje wzorce z `DangerousCommandPatterns`. | Tak |
| `GrepTool` | Przeszukuje treść plików regexem (limit 5000 plików, timeout na regex). | Nie |
| `GlobTool` | Szuka plików wg wzorca (`**/*.cs`). | Nie |
| `CodeSearchTool` | Wyszukiwanie semantyczne (embeddingi OpenAI) — gdy nie wiadomo, czego grepować. | Nie |
| `PlanTool` | Checkpoint przed dużą zmianą — reużywa mechanizm potwierdzenia jako bramkę akceptacji planu. | Tak |
| `TaskTool` | Deleguje samodzielne pod-zadanie do odizolowanego subagenta (własna rozmowa, te same narzędzia minus `Task`). | Nie (subagent i tak pyta o swoje własne akcje) |

Wspólna infrastruktura:
- `ITool` — kontrakt (Command pattern) + domyślne metody `FormatConfirmation`/`VerifyBuildAfterInvoke`.
- `IToolFunctionAdapter` / `ToolFunctionAdapter` — składa łańcuch dekoratorów (build-verify → permission-gate) wokół surowego narzędzia.
- `IFileReadTracker` / `FileReadTracker` — pamięta, które pliki agent faktycznie przeczytał w tej sesji (guard "nie edytuj na ślepo").
- `FileContentGuard` — cap rozmiaru pliku + ścisła walidacja UTF-8 (odrzuca pliki binarne).
- `DangerousCommandPatterns` — heurystyczna denylist (`rm -rf`, fork bomb, `sudo`, `curl | sh`...).
- `ToolArgumentFormatter` — wspólne formatowanie argumentów do UI (skracanie długich wartości).
- `SelfTest` — assert-based smoke test całej logiki narzędzi i mechanizmów bezpieczeństwa, bez sieci (`--self-test`).

### `Permissions/` — bramka potwierdzeń

| Plik | Odpowiedzialność |
|---|---|
| `IPermissionGate` / `ConsolePermissionGate` | Pyta użytkownika o zgodę (y/n/a) przed ryzykowną akcją. Pamięta "zawsze" (`a`) per narzędzie na czas procesu. |
| `PermissionGatedAIFunction` | Decorator: owija `AIFunction`, wywołuje `IPermissionGate` przed faktycznym wykonaniem narzędzia. |

### `Verification/` — powłoka i automatyczna weryfikacja

| Plik | Odpowiedzialność |
|---|---|
| `IBashRunner` / `BashRunner` | Jednorazowy `/bin/sh` zawsze z workspace root — używany **tylko** do auto-weryfikacji builda, żeby była deterministyczna niezależnie od tego, gdzie agent sobie `cd`-ował. |
| `IPersistentShell` / `PersistentShell` | Jeden długożyjący `/bin/bash` na całą sesję — `cd`/`export`/zmienne przeżywają kolejne wywołania, jak prawdziwy terminal. Tego używa `BashTool` i komendy `!`. |
| `IProjectCommandDetector` / `ProjectCommandDetector` | Wykrywa (i cache'uje) komendę build/test repo: `.csproj`→dotnet, `package.json`→npm, `Makefile`→make, `pyproject.toml`→pytest. |
| `IBuildVerifier` / `BuildVerifier` + `BuildVerifyingAIFunction` | Decorator: po każdym udanym `Write`/`Edit` automatycznie odpala wykrytą komendę build i dokleja wynik (OK/FAILED) do odpowiedzi narzędzia. |

### `Workspace/` — sandbox ścieżek

`IWorkspaceGuard` / `WorkspaceGuard` — jedyny arbiter tego, czy ścieżka jest "wewnątrz" repozytorium. Odrzuca ścieżki poza katalogiem startowym **i** ścieżki przechodzące przez symlink (nawet jeśli leksykalnie wyglądają na bezpieczne) — sprawdzane przez `Read`/`Write`/`Edit`/`Grep`/`Glob`/`CodeSearch` per plik/katalog.

### `Search/` — wyszukiwanie semantyczne

`IEmbeddingIndex` / `InMemoryEmbeddingIndex` — indeksuje repo (embeddingi OpenAI, cache w pamięci procesu, invalidacja po mtime pliku) i zwraca top-K fragmentów najbliższych zapytaniu (cosine similarity). `CodeChunk` — pojedynczy zaindeksowany fragment pliku.

### `Session/` — trwałość rozmowy

`ISessionStore` / `FileSessionStore` — zapisuje/odczytuje zserializowaną historię rozmowy do `.codeagent/session.json`, żeby przeżyła restart programu.

### `Diagnostics/` — obserwowalność i koszt

| Plik | Odpowiedzialność |
|---|---|
| `FileLoggerProvider` | Minimalny logger zapisujący do `.codeagent/agent.log` (nie do konsoli — tę zajmuje UI). |
| `IUsageTracker` / `UsageTracker` | Sumuje zużycie tokenów (input/output) w trakcie sesji, pokazywane przez `/usage`. |

### `Config/` — konfiguracja

`AgentOptions` — model, klucz API, limity, timeouty (patrz sekcja 5). `AgentOptionsFormatter` — bezpieczne renderowanie configu do wyświetlenia (klucz zawsze zamaskowany), używane i przez `--show-config`, i przez `/config`.

### `Repl/` — pętla interakcji

| Plik | Odpowiedzialność |
|---|---|
| `ReplSession` | Główna pętla: czyta input, klasyfikuje przez `ReplInput`, wykonuje odpowiednią ścieżkę (chat / slash / shell / wyjście), zapisuje sesję na końcu. |
| `ReplInput` | Czysta funkcja parsująca surowy string na typowany wariant (patrz 3.2). |
| `TurnRenderer` | Renderuje strumień odpowiedzi modelu (bullet'y narzędzi, wyniki, tekst), zbiera usage, ostrzega przy dużej historii rozmowy. |
| `Repl/Commands/*` | `ISlashCommand` (Command pattern) + `SlashCommandRegistry` (dispatch po nazwie) + `SlashCommandParser` (czyste parsowanie `/nazwa argument`). Konkretne komendy: `/help`, `/exit`, `/clear`, `/config`, `/model`, `/usage`. |

### `Ui/` — prezentacja terminalowa

`IConsoleUi` / `SpectreConsoleUi` — cały wygląd (Spectre.Console): baner startowy, bullet'y narzędzi (`● Tool(args)`), kolorowany diff w panelu potwierdzenia, spinner, komunikaty info/error. `ConfirmResult` — wynik pytania o zgodę (Deny/Allow/AlwaysAllow).

---

## 5. Konfiguracja

Kolejność pierwszeństwa: **zmienne środowiskowe / `.env.local` > `appsettings.json` > wartości domyślne w kodzie**.

| Ustawienie | appsettings.json (`Agent:`) | Zmienna środowiskowa | Domyślnie |
|---|---|---|---|
| Klucz API | — (celowo nigdy tu) | `OPENAI_API_KEY` | *(wymagany)* |
| Model czatu | `Model` | `OPENAI_MODEL` | `gpt-5` |
| Model embeddingów | `EmbeddingModel` | `OPENAI_EMBEDDING_MODEL` | `text-embedding-3-small` |
| Endpoint (np. Azure/proxy) | `BaseUrl` | `OPENAI_BASE_URL` | domyślny OpenAI |
| Limit narzędzi/turę | `MaxToolIterationsPerTurn` | `OPENAI_MAX_TOOL_ITERATIONS` | `20` |
| Timeout Bash (sekundy) | `BashTimeoutSeconds` | `OPENAI_BASH_TIMEOUT_SECONDS` | `120` |

`.env.local` (gitignored) to zwykły plik `KLUCZ=wartość` — .NET go nie czyta natywnie, ładuje go ręcznie `Program.cs` do zmiennych środowiskowych procesu przed startem hosta.

---

## 6. Interakcja: trzy tryby wejścia

| Prefiks | Co się dzieje | Idzie przez LLM? |
|---|---|---|
| *(nic)* | Zwykła wiadomość do agenta | Tak |
| `/nazwa argument` | Komenda REPL (`/help`, `/model gpt-4.1`, ...) | Nie |
| `!polecenie` | Bezpośrednie wykonanie w trwałej powłoce (dzieli stan z `BashTool`) — omija permission-gate i denylistę, bo to *user* wydaje polecenie, nie model | Nie |
| `exit` / `quit` | Zapisuje sesję i kończy program | — |

---

## 7. Testowanie

`dotnet run -- --self-test` — ok. 20 grup asercji pokrywających: sandbox ścieżek (w tym ucieczkę przez symlink), guard "przeczytaj przed edycją", denylistę komend, cap plików binarnych/za dużych, always-allow w permission gate, detekcję komend build/test, auto-weryfikację builda (prawdziwy `/bin/sh`), trwałą powłokę (cd/export/exit code/timeout+restart), parsowanie komend i `ReplInput`. Bez sieci, bez klucza API.

---

## 8. Świadomie pominięte / znane ograniczenia

- **Nie ma prawdziwego sandboxu OS-owego** — `Bash`/`!` mogą `cd` poza workspace; jedyna bariera to denylist wzorców i to, że user widzi komendę przed potwierdzeniem.
- **Brak prawdziwej kompakcji historii rozmowy** — framework nie udostępnia API do przycinania wiadomości sesji, więc jest tylko jednorazowe ostrzeżenie przy dużym zużyciu tokenów (sugestia `/clear`), nie automatyczne obcinanie.
- **Brak procesów w tle** (odpowiednik `run_in_background`/`BashOutput`/`KillShell` z Claude Code) — każda komenda Bash jest synchroniczna względem tury.
- **CodeSearch nie ma trwałego indeksu wektorowego** — embeddingi liczone od nowa przy każdym starcie procesu; ok dla małych/średnich repo.
- **Limit iteracji narzędzi liczy round-tripy, nie pojedyncze wywołania** — model może zbatchować kilka wywołań w jedną iterację, więc limit w praktyce jest "miękki" dla równoległych wywołań.

---

## 9. Jak rozszerzyć system

Cztery najczęstsze rozszerzenia i gotowa ścieżka dla każdego. Trzy pierwsze (tool, komenda, UI) mają czyste, gotowe do podłączenia interfejsy — dopisujesz klasę i jedną linijkę w `Program.cs`. Czwarte (provider AI) jest dziś ukształtowane pod OpenAI i wymaga świadomej decyzji, patrz 9.2.

### 9.1 Nowy tool (`ITool`)

1. Nowa klasa w `Tools/`, implementuje `ITool`. `Handler` wskazuje na prywatną metodę — jej sygnatura (typy parametrów + atrybuty `[Description]`) jest reflektowana na schemat JSON, którym model faktycznie widzi narzędzie.

```csharp
// Tools/WordCountTool.cs
using System.ComponentModel;
using CodeAgent.Workspace;

namespace CodeAgent.Tools;

public sealed class WordCountTool : ITool
{
    private readonly IWorkspaceGuard _workspace; // wstrzykuj, jeśli tool dotyka ścieżek na dysku

    public WordCountTool(IWorkspaceGuard workspace) => _workspace = workspace;

    public string Name => "WordCount";
    public string Description => "Liczy słowa w pliku tekstowym.";
    public bool RequiresConfirmation => false; // true, jeśli tool coś zmienia/wykonuje
    public Delegate Handler => Execute;

    [Description("Liczy słowa w pliku tekstowym")]
    private string Execute([Description("Ścieżka do pliku")] string filePath)
    {
        if (_workspace.Validate(filePath) is { } error)
            return error;

        if (!File.Exists(filePath))
            return $"Error: file not found: {filePath}";

        var count = File.ReadAllText(filePath).Split(' ', StringSplitOptions.RemoveEmptyEntries).Length;
        return $"{count} słów";
    }
}
```

2. Rejestracja w `Program.cs`, obok pozostałych worker-tools:
```csharp
builder.Services.AddSingleton<ITool, WordCountTool>();
```
3. Jeśli tool modyfikuje pliki: ustaw `RequiresConfirmation => true` (dostaje wtedy automatycznie panel potwierdzenia z `IPermissionGate`) i rozważ `VerifyBuildAfterInvoke => true` (dostaje automatyczny build-verify po wykonaniu — patrz `EditTool`/`WriteTool`). Dla lepszego panelu potwierdzenia nadpisz `FormatConfirmation(...)` (patrz `EditTool` — generuje tam diff zamiast surowego zrzutu argumentów).
4. Dodaj wpis w `Tools/SelfTest.cs` (wzór: dowolna z metod `RunXyz()`) — narzędzie testujesz przez `new WordCountTool(...).Handler.DynamicInvoke(...)`, bez potrzeby klucza API.
5. Opcjonalnie: dopisz jedno zdanie w `Agent/SystemPrompt.cs`, jeśli model ma wiedzieć *kiedy* używać nowego narzędzia (tak jak jest to zrobione dla `CodeSearch`/`Task`/`Plan`).

### 9.2 Nowy provider AI

Seam jest teraz **kształtu frameworku**: `IChatClientProvider` zwraca `Microsoft.Extensions.AI.IChatClient`, nie konkretny SDK-owy typ. `ChatAgentBuilder` buduje agenta wprost z `ChatClientAgent` (konstruktor generyczny z `Microsoft.Agents.AI`), więc nie zależy już od rozszerzenia specyficznego dla OpenAI. Embeddingi (`CodeSearchTool`/`InMemoryEmbeddingIndex`) mają osobny seam, `IEmbeddingClientProvider` — framework nie ma tu wspólnej abstrakcji, więc został OpenAI-kształtu celowo.

**Ścieżka A — endpoint kompatybilny z OpenAI API** (Azure OpenAI, OpenRouter, lokalny vLLM/Ollama/LM Studio z trybem OpenAI-compat) — **zero zmian w kodzie**, to już działa:
```
OPENAI_BASE_URL=https://twoj-endpoint/v1
OPENAI_API_KEY=...
OPENAI_MODEL=nazwa-modelu-u-tego-providera
```
`OpenAIClientOptions.Endpoint` jest już respektowany w `Agent/OpenAIClientProvider.cs`. To pokrywa większość realnych przypadków "chcę innego dostawcy".

**Ścieżka B — inny protokół/SDK** (np. natywne Anthropic API, Google Gemini, cokolwiek bez warstwy OpenAI-compat):

1. Dodaj pakiet z adapterem `IChatClient` dla nowego providera (ekosystem Microsoft.Extensions.AI ma je dla wielu dostawców; w ostateczności napisz własny — kontrakt to jedna metoda `GetStreamingResponseAsync`).
2. Napisz nową implementację `IChatClientProvider` (patrz `Agent/IChatClientProvider.cs`) zamiast `OpenAIClientProvider`.
3. Zarejestruj ją w `Program.cs` zamiast `OpenAIClientProvider` pod `IChatClientProvider`. Jeśli nowy provider nie ma API do embeddingów, albo zostaw `IEmbeddingClientProvider` zarejestrowany na `OpenAIClientProvider` (oba klienty mogą współistnieć), albo dopisz analogiczną implementację `IEmbeddingClientProvider`.

### 9.3 Nowa komenda `/nazwa`

1. Nowa klasa w `Repl/Commands/`, implementuje `ISlashCommand`:
```csharp
// Repl/Commands/VersionSlashCommand.cs
using CodeAgent.Ui;

namespace CodeAgent.Repl.Commands;

public sealed class VersionSlashCommand : ISlashCommand
{
    private readonly IConsoleUi _ui;
    public VersionSlashCommand(IConsoleUi ui) => _ui = ui;

    public string Name => "version";
    public string Description => "Pokaż wersję CodeAgent";

    public SlashCommandEffect Execute(string argument)
    {
        _ui.ShowInfo("CodeAgent 0.1.0");
        return SlashCommandEffect.None; // albo ResetSession / RebuildAgent / Exit — patrz ModelSlashCommand/ClearSlashCommand
    }
}
```
2. Rejestracja w `Program.cs`, obok pozostałych:
```csharp
builder.Services.AddSingleton<ISlashCommand, VersionSlashCommand>();
```
3. Nic więcej — `/help` automatycznie ją wypisze (`HelpSlashCommand` enumeruje kolekcję `ISlashCommand` w DI), a `SlashCommandRegistry` automatycznie obsłuży dispatch po nazwie.
4. Jeśli komenda ma wpływać na stan rozmowy/agenta (jak `/clear` czy `/model`), nie rób tego bezpośrednio w komendzie — zwróć odpowiedni `SlashCommandEffect`, `ReplSession.RunAsync` go zaaplikuje (tam żyją `agent`/`session`, komendy ich nie widzą).

### 9.4 Nowy UI (`IConsoleUi`)

Cała prezentacja terminalowa siedzi za jednym interfejsem — podmiana `SpectreConsoleUi` na coś innego (np. gołe `Console.WriteLine` do logów CI, albo UI webowe) nie rusza `ReplSession`/`TurnRenderer`/`ConsolePermissionGate`.

1. Nowa klasa implementująca `IConsoleUi` (pełna lista członków w `Ui/IConsoleUi.cs`: `ShowBanner`, `ReadInput`, `ShowToolCall`, `ShowToolResult`, `WriteAssistantChunk`, `EndAssistantTurn`, `WithSpinnerAsync`, `Confirm`, `ShowInfo`, `ShowError`, `ShowShellCommand`).
2. **Ważne ograniczenie:** `ReadInput()` i `Confirm(...)` muszą działać na zwykłym `Console.ReadLine()`, nie na interaktywnych widgetach (np. Spectre `TextPrompt`/`SelectionPrompt` z obsługą strzałek) — te używają `Console.ReadKey`, co wywala się przy przekierowanym/pipowanym stdin (patrz testy w tym repo, uruchamiane właśnie przez pipe). Jeśli Twój UI nie musi wspierać pipe'owania, ten warunek możesz świadomie złamać.
3. Rejestracja w `Program.cs` — podmień jedną linijkę:
```csharp
builder.Services.AddSingleton<IConsoleUi, TwojUi>(); // zamiast SpectreConsoleUi
```
4. Minimalny szkielet bez zależności od Spectre (np. do logów/CI):
```csharp
public sealed class PlainConsoleUi : IConsoleUi
{
    public void ShowBanner(string model, string cwd, bool resumedSession) =>
        Console.WriteLine($"CodeAgent — model: {model}, cwd: {cwd}");
    public string? ReadInput() { Console.Write("> "); return Console.ReadLine(); }
    public void ShowToolCall(string name, string argsSummary) => Console.WriteLine($"[{name}] {argsSummary}");
    public void ShowToolResult(string resultSummary) => Console.WriteLine($"  -> {resultSummary}");
    public void WriteAssistantChunk(string text) => Console.Write(text);
    public void EndAssistantTurn() => Console.WriteLine();
    public Task<T> WithSpinnerAsync<T>(string label, Func<Task<T>> action) => action();
    public ConfirmResult Confirm(string toolName, string argsSummary)
    {
        Console.Write($"[{toolName}] {argsSummary}\nZezwolić? (y/n/a) ");
        return Console.ReadLine()?.Trim().ToLowerInvariant() switch
        {
            "a" => ConfirmResult.AlwaysAllow,
            "y" => ConfirmResult.Allow,
            _ => ConfirmResult.Deny,
        };
    }
    public void ShowInfo(string message) => Console.WriteLine(message);
    public void ShowError(string message) => Console.Error.WriteLine(message);
    public void ShowShellCommand(string command) => Console.WriteLine($"! {command}");
}
```

### 9.5 Nowy weryfikator

"Weryfikator" to dziś jeden konkretny mechanizm: `IBuildVerifier`/`BuildVerifyingAIFunction`, decorator który po `Write`/`Edit` sam odpala komendę builda i dokleja wynik do odpowiedzi narzędzia (patrz 4, `Verification/`). Rozszerzasz go na dwóch różnych poziomach, w zależności od potrzeby.

**9.5.1 Nowy typ projektu (najczęstszy przypadek)** — nie trzeba nic w `Verification/IBuildVerifier`/`BuildVerifyingAIFunction` ruszać, wystarczy nauczyć `ProjectCommandDetector` rozpoznawać kolejny ekosystem. Dopisz gałąź w `Verification/ProjectCommandDetector.cs`:

```csharp
private static ProjectCommands DetectCore(string root)
{
    if (Directory.EnumerateFiles(root, "*.sln", SearchOption.TopDirectoryOnly).Any() ||
        Directory.EnumerateFiles(root, "*.csproj", SearchOption.AllDirectories).Any())
        return new ProjectCommands("dotnet build", "dotnet test");

    // nowy przypadek: Rust
    if (File.Exists(Path.Combine(root, "Cargo.toml")))
        return new ProjectCommands("cargo build", "cargo test");

    var packageJson = Path.Combine(root, "package.json");
    // ... reszta bez zmian
}
```
Dodaj też przypadek do `Tools/SelfTest.cs` → `RunProjectCommandDetector` (wzór: istniejące bloki dla dotnet/npm/make) — to jest czysta funkcja, testujesz ją bez sieci i bez klucza.

**9.5.2 Nowy rodzaj weryfikacji (np. auto-uruchamianie testów, linter)** — dziś `ProjectCommands.Test` jest wykrywane, ale **nic go automatycznie nie uruchamia** (agent dostaje tylko sugestię w system prompcie, żeby zrobił to sam przez `Bash`). Żeby dodać drugi, w pełni automatyczny weryfikator obok builda, powiel dokładnie ten sam trójkąt Decorator + Strategy + flaga na `ITool`, którego już używa build-verify:

1. **Interfejs + decorator** — kopia `IBuildVerifier`/`BuildVerifyingAIFunction`, tylko czyta `commands.Test` zamiast `commands.Build`:
```csharp
// Verification/ITestVerifier.cs
public interface ITestVerifier
{
    AIFunction Wrap(AIFunction inner);
}

// Verification/TestVerifyingAIFunction.cs — kopiuj BuildVerifyingAIFunction, zamień
// commands.Build → commands.Test i treść komunikatu "[auto-verify: ... → OK/FAILED]".

// Verification/TestVerifier.cs
public sealed class TestVerifier : ITestVerifier
{
    private readonly IProjectCommandDetector _detector;
    private readonly IBashRunner _bashRunner;
    public TestVerifier(IProjectCommandDetector detector, IBashRunner bashRunner) { ... }
    public AIFunction Wrap(AIFunction inner) => new TestVerifyingAIFunction(inner, _detector, _bashRunner);
}
```
2. **Flaga na `ITool`** — analogicznie do `VerifyBuildAfterInvoke`:
```csharp
bool VerifyTestsAfterInvoke => false;
```
3. **Wpięcie w `ToolFunctionAdapter.Adapt`** — kolejny `if`, w tej samej kolejności co dziś (build/test verify **przed** permission-gate, żeby user widział już zweryfikowany wynik w panelu potwierdzenia, a nie surowy):
```csharp
if (tool.VerifyBuildAfterInvoke)
    function = _buildVerifier.Wrap(function);
if (tool.VerifyTestsAfterInvoke)
    function = _testVerifier.Wrap(function);
if (tool.RequiresConfirmation)
    function = new PermissionGatedAIFunction(function, _gate, tool);
```
4. Rejestracja w `Program.cs`: `builder.Services.AddSingleton<ITestVerifier, TestVerifier>();`
5. Ustaw `VerifyTestsAfterInvoke => true` w `EditTool`/`WriteTool` (albo tylko tam, gdzie ma sens — np. nie przy każdej edycji, jeśli testy są wolne).

**Uwaga na koszt:** tak jak build-verify (patrz komentarz `ponytail:` w `BuildVerifyingAIFunction`), auto-testy po *każdym* `Edit` mogą być wolne na większym repo z długim test suite'em. Rozważ wtedy odpalanie tylko raz na koniec tury (hook na zakończenie `RunTurnAsync` w `ReplSession`), nie po każdym pojedynczym wywołaniu narzędzia.

**Inny wariant rozszerzenia — inne środowisko uruchomienia.** Jeśli chcesz, żeby weryfikacja (albo `Bash` w ogóle) leciała np. w kontenerze Docker zamiast gołego `/bin/sh` na hoście, podmień implementację `IBashRunner` (dla jednorazowego build-verify) i/lub `IPersistentShell` (dla interaktywnej sesji agenta) — obie to Strategy, `BuildVerifier`/`BuildVerifyingAIFunction` i `BashTool` nie wiedzą i nie chcą wiedzieć, *gdzie* fizycznie komenda się wykonuje.
