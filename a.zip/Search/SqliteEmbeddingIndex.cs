using System.Runtime.InteropServices;
using CodeAgent.Agent;
using CodeAgent.Config;
using CodeAgent.Workspace;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Options;
using OpenAI.Embeddings;

namespace CodeAgent.Search;

/// <summary>
/// Semantic code search backed by OpenAI embeddings, persisted in .codeagent/embeddings.db so re-runs
/// only re-embed files that changed since the last index (by mtime) instead of the whole repo.
/// </summary>
public sealed class SqliteEmbeddingIndex : IEmbeddingIndex, IDisposable
{
    private static readonly string[] IncludedExtensions =
        [".cs", ".ts", ".tsx", ".js", ".py", ".java", ".go", ".rs", ".md", ".json", ".yml", ".yaml", ".razor"];

    private static readonly string[] ExcludedDirs = ["bin", "obj", ".git", "node_modules", ".codeagent"];

    private const int ChunkLines = 60;
    private const long MaxFileBytes = 200_000;

    private readonly IEmbeddingClientProvider _clientProvider;
    private readonly AgentOptions _options;
    private readonly IWorkspaceGuard _workspace;
    private readonly SqliteConnection _db;
    private readonly SemaphoreSlim _indexLock = new(1, 1);

    public SqliteEmbeddingIndex(IEmbeddingClientProvider clientProvider, IOptions<AgentOptions> options, IWorkspaceGuard workspace)
    {
        _clientProvider = clientProvider;
        _options = options.Value;
        _workspace = workspace;

        var dataDir = Path.Combine(_workspace.Root, ".codeagent");
        Directory.CreateDirectory(dataDir);
        _db = new SqliteConnection($"Data Source={Path.Combine(dataDir, "embeddings.db")}");
        _db.Open();

        using var cmd = _db.CreateCommand();
        cmd.CommandText = """
            CREATE TABLE IF NOT EXISTS chunks (
                file TEXT NOT NULL,
                mtime TEXT NOT NULL,
                start_line INTEGER NOT NULL,
                text TEXT NOT NULL,
                embedding BLOB NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_chunks_file ON chunks(file);
            """;
        cmd.ExecuteNonQuery();
    }

    public void Dispose() => _db.Dispose();

    public async Task<IReadOnlyList<SearchHit>> SearchAsync(
        string query, string root, int topK, CancellationToken cancellationToken)
    {
        var embeddingClient = _clientProvider.GetEmbeddingClient(_options.EmbeddingModel);
        await IndexAsync(embeddingClient, root, cancellationToken);

        var queryEmbedding = (await embeddingClient.GenerateEmbeddingAsync(query, cancellationToken: cancellationToken))
            .Value.ToFloats();

        using var cmd = _db.CreateCommand();
        cmd.CommandText = "SELECT file, start_line, text, embedding FROM chunks";
        using var reader = cmd.ExecuteReader();

        var hits = new List<SearchHit>();
        while (reader.Read())
        {
            var embedding = ToFloats((byte[])reader["embedding"]);
            var score = CosineSimilarity(queryEmbedding.Span, embedding);
            hits.Add(new SearchHit((string)reader["file"], (int)(long)reader["start_line"], (string)reader["text"], score));
        }

        return hits.OrderByDescending(h => h.Score).Take(topK).ToList();
    }

    private async Task IndexAsync(EmbeddingClient embeddingClient, string root, CancellationToken cancellationToken)
    {
        await _indexLock.WaitAsync(cancellationToken);
        try
        {
            var files = Directory.EnumerateFiles(root, "*", SearchOption.AllDirectories)
                .Where(f => IncludedExtensions.Contains(Path.GetExtension(f)))
                .Where(f => !f.Split(Path.DirectorySeparatorChar).Any(ExcludedDirs.Contains))
                .Where(f => new FileInfo(f).Length <= MaxFileBytes)
                // Recursion can walk into a symlinked subdirectory leading outside the workspace even
                // though root itself was validated — re-check each candidate before embedding it.
                .Where(f => _workspace.Validate(f) is null);

            foreach (var file in files)
            {
                var mtime = File.GetLastWriteTimeUtc(file).Ticks.ToString();
                if (GetCachedMTime(file) == mtime)
                    continue;

                string[] lines;
                try
                {
                    lines = File.ReadAllLines(file);
                }
                catch (IOException)
                {
                    continue;
                }

                var chunks = Chunk(file, lines);

                using var delete = _db.CreateCommand();
                delete.CommandText = "DELETE FROM chunks WHERE file = $file";
                delete.Parameters.AddWithValue("$file", file);
                delete.ExecuteNonQuery();

                if (chunks.Count == 0)
                    continue;

                var embeddings = (await embeddingClient.GenerateEmbeddingsAsync(
                    chunks.Select(c => c.Text), cancellationToken: cancellationToken)).Value;

                using var transaction = _db.BeginTransaction();
                foreach (var (chunk, embedding) in chunks.Zip(embeddings))
                {
                    using var insert = _db.CreateCommand();
                    insert.Transaction = transaction;
                    insert.CommandText = """
                        INSERT INTO chunks (file, mtime, start_line, text, embedding)
                        VALUES ($file, $mtime, $startLine, $text, $embedding)
                        """;
                    insert.Parameters.AddWithValue("$file", chunk.File);
                    insert.Parameters.AddWithValue("$mtime", mtime);
                    insert.Parameters.AddWithValue("$startLine", chunk.StartLine);
                    insert.Parameters.AddWithValue("$text", chunk.Text);
                    insert.Parameters.AddWithValue("$embedding", ToBytes(embedding.ToFloats().Span));
                    insert.ExecuteNonQuery();
                }
                transaction.Commit();
            }
        }
        finally
        {
            _indexLock.Release();
        }
    }

    private string? GetCachedMTime(string file)
    {
        using var cmd = _db.CreateCommand();
        cmd.CommandText = "SELECT mtime FROM chunks WHERE file = $file LIMIT 1";
        cmd.Parameters.AddWithValue("$file", file);
        return cmd.ExecuteScalar() as string;
    }

    private static byte[] ToBytes(ReadOnlySpan<float> floats) => MemoryMarshal.AsBytes(floats).ToArray();

    private static float[] ToFloats(byte[] bytes) => MemoryMarshal.Cast<byte, float>(bytes).ToArray();

    internal static List<CodeChunk> Chunk(string file, string[] lines)
    {
        var chunks = new List<CodeChunk>();
        for (var i = 0; i < lines.Length; i += ChunkLines)
        {
            var text = string.Join('\n', lines.Skip(i).Take(ChunkLines));
            if (!string.IsNullOrWhiteSpace(text))
                chunks.Add(new CodeChunk(file, i + 1, text, ReadOnlyMemory<float>.Empty));
        }

        return chunks;
    }

    internal static float CosineSimilarity(ReadOnlySpan<float> a, ReadOnlySpan<float> b)
    {
        float dot = 0, normA = 0, normB = 0;
        for (var i = 0; i < a.Length; i++)
        {
            dot += a[i] * b[i];
            normA += a[i] * a[i];
            normB += b[i] * b[i];
        }

        return dot / (MathF.Sqrt(normA) * MathF.Sqrt(normB) + 1e-8f);
    }
}
