namespace CodeAgent.Search;

public readonly record struct SearchHit(string File, int StartLine, string Text, float Score);

/// <summary>Strategy for finding code relevant to a natural-language query (semantic search over the repo).</summary>
public interface IEmbeddingIndex
{
    Task<IReadOnlyList<SearchHit>> SearchAsync(
        string query, string root, int topK, CancellationToken cancellationToken);
}
