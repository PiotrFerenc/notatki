namespace CodeAgent.Search;

internal sealed record CodeChunk(string File, int StartLine, string Text, ReadOnlyMemory<float> Embedding);
