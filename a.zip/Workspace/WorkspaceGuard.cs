namespace CodeAgent.Workspace;

public sealed class WorkspaceGuard : IWorkspaceGuard
{
    public string Root { get; }

    public WorkspaceGuard()
    {
        Root = Directory.GetCurrentDirectory();
    }

    public string? Validate(string path)
    {
        string full;
        try
        {
            full = Path.GetFullPath(path);
        }
        catch (Exception ex) when (ex is ArgumentException or NotSupportedException or PathTooLongException)
        {
            return $"Error: invalid path: {path}";
        }

        var isInside = full == Root || full.StartsWith(Root + Path.DirectorySeparatorChar, StringComparison.Ordinal);
        if (!isInside)
            return $"Error: path is outside the workspace ({Root}): {path}";

        // GetFullPath is purely lexical — it doesn't resolve symlinks. A symlink anywhere between Root and
        // the target (an intermediate directory or the file itself) could point outside the workspace while
        // still lexically looking contained. Rather than resolve-and-recheck (easy to get subtly wrong on a
        // security boundary), deny outright if any segment on the way down is a symlink.
        if (PathContainsSymlink(full))
            return $"Error: path passes through a symlink, refusing for safety: {path}";

        return null;
    }

    private bool PathContainsSymlink(string fullPath)
    {
        var relative = Path.GetRelativePath(Root, fullPath);
        if (relative == ".")
            return IsSymlink(Root);

        var current = Root;
        foreach (var segment in relative.Split(Path.DirectorySeparatorChar))
        {
            current = Path.Combine(current, segment);
            if (IsSymlink(current))
                return true;
        }

        return false;
    }

    private static bool IsSymlink(string path)
    {
        if (!File.Exists(path) && !Directory.Exists(path))
            return false; // doesn't exist yet (e.g. a file Write is about to create) — can't be a symlink

        return File.GetAttributes(path).HasFlag(FileAttributes.ReparsePoint);
    }
}
