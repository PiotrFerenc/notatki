namespace CodeAgent.Workspace;

/// <summary>
/// Confines file-touching tools to the directory the agent was started in. Read/Grep/Glob/CodeSearch have no
/// permission gate at all (they're "read-only"), so without this an agent could silently read anything on
/// disk — this is the actual boundary for those. Write/Edit/Bash still go through the permission gate on top.
/// </summary>
public interface IWorkspaceGuard
{
    string Root { get; }

    /// <summary>Null if <paramref name="path"/> is inside the workspace; otherwise an error string ready to
    /// return directly as the tool's result.</summary>
    string? Validate(string path);
}
