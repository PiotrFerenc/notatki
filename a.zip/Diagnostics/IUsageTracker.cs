using Microsoft.Extensions.AI;

namespace CodeAgent.Diagnostics;

/// <summary>Accumulates token usage across a REPL session so the user has some idea what it's costing —
/// nothing surfaced this before, so cost was invisible until the OpenAI bill arrived.</summary>
public interface IUsageTracker
{
    UsageDetails Total { get; }

    void Add(UsageDetails? usage);
}
