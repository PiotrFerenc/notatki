using Microsoft.Extensions.AI;

namespace CodeAgent.Diagnostics;

public sealed class UsageTracker : IUsageTracker
{
    private readonly Lock _lock = new();

    public UsageDetails Total { get; } = new();

    public void Add(UsageDetails? usage)
    {
        if (usage is null)
            return;

        lock (_lock)
            Total.Add(usage);
    }
}
