using Microsoft.Extensions.Logging;

namespace CodeAgent.Diagnostics;

/// <summary>
/// Minimal file-backed ILoggerProvider — no NuGet package pulls in "write lines to a file". Deliberately
/// not console output: this app already owns the console for Spectre rendering, so agent-framework log
/// lines would just corrupt the UI. This gives a record to inspect after the fact instead.
/// </summary>
public sealed class FileLoggerProvider : ILoggerProvider
{
    private readonly string _path;
    private readonly Lock _lock = new();

    public FileLoggerProvider(string path)
    {
        _path = path;
        var dir = Path.GetDirectoryName(path);
        if (!string.IsNullOrEmpty(dir))
            Directory.CreateDirectory(dir);
    }

    public ILogger CreateLogger(string categoryName) => new FileLogger(categoryName, _path, _lock);

    public void Dispose()
    {
    }

    private sealed class FileLogger : ILogger
    {
        private readonly string _category;
        private readonly string _path;
        private readonly Lock _lock;

        public FileLogger(string category, string path, Lock @lock)
        {
            _category = category;
            _path = path;
            _lock = @lock;
        }

        public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;

        public bool IsEnabled(LogLevel logLevel) => logLevel >= LogLevel.Information;

        public void Log<TState>(
            LogLevel logLevel, EventId eventId, TState state, Exception? exception,
            Func<TState, Exception?, string> formatter)
        {
            if (!IsEnabled(logLevel))
                return;

            var line = $"{DateTimeOffset.Now:O} [{logLevel}] {_category}: {formatter(state, exception)}";
            if (exception is not null)
                line += $"\n{exception}";

            lock (_lock)
                File.AppendAllLines(_path, [line]);
        }
    }
}
