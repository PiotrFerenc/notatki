using CodeAgent.Agent;
using CodeAgent.Config;
using CodeAgent.Diagnostics;
using CodeAgent.Permissions;
using CodeAgent.Repl;
using CodeAgent.Repl.Commands;
using CodeAgent.Search;
using CodeAgent.Session;
using CodeAgent.Tools;
using CodeAgent.Ui;
using CodeAgent.Verification;
using CodeAgent.Workspace;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

if (args.Contains("--self-test"))
{
    CodeAgent.Tools.SelfTest.Run();
    return 0;
}

LoadDotEnvLocal();

var builder = Host.CreateApplicationBuilder(args);

// Spectre owns the console for the REPL UI — default console logging would corrupt that, so replace it
// with a file sink instead. Gives a record of what the agent actually did, checkable after the fact.
builder.Logging.ClearProviders();
builder.Logging.AddProvider(new FileLoggerProvider(
    Path.Combine(Directory.GetCurrentDirectory(), ".codeagent", "agent.log")));

// appsettings.json ("Agent" section) sets the non-secret defaults; OPENAI_* env vars (e.g. from
// .env.local) always win on top — keeps the API key out of any file that could end up in git.
builder.Services.Configure<AgentOptions>(builder.Configuration.GetSection(AgentOptions.SectionName));
builder.Services.PostConfigure<AgentOptions>(options =>
{
    options.ApiKey = builder.Configuration["OPENAI_API_KEY"] ?? options.ApiKey;
    options.Model = builder.Configuration["OPENAI_MODEL"] ?? options.Model;
    options.EmbeddingModel = builder.Configuration["OPENAI_EMBEDDING_MODEL"] ?? options.EmbeddingModel;
    options.BaseUrl = builder.Configuration["OPENAI_BASE_URL"] ?? options.BaseUrl;

    if (int.TryParse(builder.Configuration["OPENAI_MAX_TOOL_ITERATIONS"], out var maxIterations))
        options.MaxToolIterationsPerTurn = maxIterations;
    if (int.TryParse(builder.Configuration["OPENAI_BASH_TIMEOUT_SECONDS"], out var bashTimeout))
        options.BashTimeoutSeconds = bashTimeout;
});

builder.Services.AddSingleton<IConsoleUi, SpectreConsoleUi>();
builder.Services.AddSingleton<IPermissionGate, ConsolePermissionGate>();
builder.Services.AddSingleton<OpenAIClientProvider>();
builder.Services.AddSingleton<IChatClientProvider>(sp => sp.GetRequiredService<OpenAIClientProvider>());
builder.Services.AddSingleton<IEmbeddingClientProvider>(sp => sp.GetRequiredService<OpenAIClientProvider>());
builder.Services.AddSingleton<IChatAgentBuilder, ChatAgentBuilder>();
builder.Services.AddSingleton<IEmbeddingIndex, SqliteEmbeddingIndex>();
builder.Services.AddSingleton<ISessionStore, FileSessionStore>();
builder.Services.AddSingleton<IFileReadTracker, FileReadTracker>();
builder.Services.AddSingleton<IProjectCommandDetector, ProjectCommandDetector>();
builder.Services.AddSingleton<IBashRunner, BashRunner>();
builder.Services.AddSingleton<IPersistentShell, PersistentShell>();
builder.Services.AddSingleton<IBuildVerifier, BuildVerifier>();
builder.Services.AddSingleton<IToolFunctionAdapter, ToolFunctionAdapter>();
builder.Services.AddSingleton<IWorkspaceGuard, WorkspaceGuard>();
builder.Services.AddSingleton<IUsageTracker, UsageTracker>();

// Worker tools: the collection TaskTool hands to its sub-agents. TaskTool itself is registered
// separately below (not as ITool) so resolving this collection can never recurse into it.
builder.Services.AddSingleton<ITool, ReadTool>();
builder.Services.AddSingleton<ITool, WriteTool>();
builder.Services.AddSingleton<ITool, EditTool>();
builder.Services.AddSingleton<ITool, BashTool>();
builder.Services.AddSingleton<ITool, GrepTool>();
builder.Services.AddSingleton<ITool, GlobTool>();
builder.Services.AddSingleton<ITool, CodeSearchTool>();
builder.Services.AddSingleton<ITool, PlanTool>();
builder.Services.AddSingleton<TaskTool>();

builder.Services.AddSingleton<IAgentFactory, OpenAIAgentFactory>();
builder.Services.AddSingleton<TurnRenderer>();
builder.Services.AddSingleton<ReplSession>();

// Same split as TaskTool/workerTools: leaf slash commands go in the ISlashCommand collection,
// HelpSlashCommand is registered on its own so listing "every command" can't cycle into itself.
builder.Services.AddSingleton<ISlashCommand, ExitSlashCommand>();
builder.Services.AddSingleton<ISlashCommand, ClearSlashCommand>();
builder.Services.AddSingleton<ISlashCommand, ConfigSlashCommand>();
builder.Services.AddSingleton<ISlashCommand, ModelSlashCommand>();
builder.Services.AddSingleton<ISlashCommand, UsageSlashCommand>();
builder.Services.AddSingleton<HelpSlashCommand>();
builder.Services.AddSingleton<SlashCommandRegistry>();

using var host = builder.Build();

var agentOptions = host.Services.GetRequiredService<Microsoft.Extensions.Options.IOptions<AgentOptions>>().Value;

if (args.Contains("--show-config"))
{
    Console.WriteLine(AgentOptionsFormatter.Format(agentOptions));
    return 0;
}

if (string.IsNullOrWhiteSpace(agentOptions.ApiKey))
{
    Console.Error.WriteLine("Brak klucza API. Ustaw zmienną środowiskową OPENAI_API_KEY.");
    return 1;
}

using var cts = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) =>
{
    e.Cancel = true;
    cts.Cancel();
};

await host.Services.GetRequiredService<ReplSession>().RunAsync(cts.Token);
return 0;

// .env files aren't a .NET concept — nothing reads them automatically. This loads KEY=VALUE
// lines into process env vars (without overwriting ones already set by the real shell) so the
// EnvironmentVariables configuration provider Host.CreateApplicationBuilder wires in picks them up.
static void LoadDotEnvLocal()
{
    var path = Path.Combine(Directory.GetCurrentDirectory(), ".env.local");
    if (!File.Exists(path))
        return;

    foreach (var line in File.ReadAllLines(path))
    {
        var trimmed = line.Trim();
        if (trimmed.Length == 0 || trimmed.StartsWith('#'))
            continue;

        var separatorIndex = trimmed.IndexOf('=');
        if (separatorIndex < 0)
            continue;

        var key = trimmed[..separatorIndex].Trim();
        var value = trimmed[(separatorIndex + 1)..].Trim().Trim('"');

        if (Environment.GetEnvironmentVariable(key) is null)
            Environment.SetEnvironmentVariable(key, value);
    }
}
