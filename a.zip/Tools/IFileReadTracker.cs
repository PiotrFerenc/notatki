namespace CodeAgent.Tools;

/// <summary>Tracks which files the agent has actually Read this run, so Edit/overwriting Write can refuse
/// to touch a file blind. Shared (singleton) across the main agent and any Task sub-agents.</summary>
public interface IFileReadTracker
{
    void MarkRead(string filePath);

    bool HasBeenRead(string filePath);
}
