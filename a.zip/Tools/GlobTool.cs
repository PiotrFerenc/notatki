using System.ComponentModel;
using CodeAgent.Workspace;
using Microsoft.Extensions.FileSystemGlobbing;

namespace CodeAgent.Tools;

public sealed class GlobTool : ITool
{
    private readonly IWorkspaceGuard _workspace;

    public GlobTool(IWorkspaceGuard workspace)
    {
        _workspace = workspace;
    }

    public string Name => "Glob";

    public string Description => "Finds files matching a glob pattern, e.g. **/*.cs";

    public bool RequiresConfirmation => false;

    public Delegate Handler => Execute;

    [Description("Finds files matching a glob pattern")]
    private string Execute(
        [Description("Glob pattern, e.g. **/*.cs")] string pattern,
        [Description("Base directory, defaults to the current directory")] string? path = null)
    {
        var root = path ?? Directory.GetCurrentDirectory();
        if (_workspace.Validate(root) is { } workspaceError)
            return workspaceError;

        var matcher = new Matcher();
        matcher.AddInclude(pattern);

        var matches = matcher.GetResultsInFullPath(root)
            .Where(f => _workspace.Validate(f) is null)
            .ToList();
        return matches.Count == 0 ? "No matches" : string.Join('\n', matches);
    }
}
