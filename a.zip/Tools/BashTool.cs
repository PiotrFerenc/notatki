using System.ComponentModel;
using CodeAgent.Verification;

namespace CodeAgent.Tools;

public sealed class BashTool : ITool
{
    private readonly IPersistentShell _shell;

    public BashTool(IPersistentShell shell)
    {
        _shell = shell;
    }

    public string Name => "Bash";

    public string Description =>
        "Executes a shell command in a persistent bash session — like a real terminal, cd and exported " +
        "env vars carry over to your next Bash call. Returns combined stdout/stderr.";

    public bool RequiresConfirmation => true;

    public Delegate Handler => ExecuteAsync;

    [Description("Executes a shell command and returns its output")]
    private async Task<string> ExecuteAsync(
        [Description("Shell command to run")] string command,
        CancellationToken cancellationToken)
    {
        if (DangerousCommandPatterns.IsDangerous(command))
            return "Error: this command matches a blocked destructive pattern (e.g. rm -rf, fork bomb, " +
                   "piping a download into a shell, sudo) and was not run.";

        var result = await _shell.RunAsync(command, cancellationToken);
        return $"exit {result.ExitCode}\n{result.Output}";
    }
}
