using System.Collections.Concurrent;

namespace CodeAgent.Tools;

public sealed class FileReadTracker : IFileReadTracker
{
    private readonly ConcurrentDictionary<string, byte> _readFiles = new();

    public void MarkRead(string filePath) => _readFiles[Key(filePath)] = 0;

    public bool HasBeenRead(string filePath) => _readFiles.ContainsKey(Key(filePath));

    private static string Key(string filePath) => Path.GetFullPath(filePath);
}
