namespace CodeAgent.Tools;

/// <summary>Single place that turns tool call arguments into a short, human-readable summary —
/// reused by the permission dialog and the "● Tool(args)" call-line in the UI.</summary>
internal static class ToolArgumentFormatter
{
    private const int MaxValueLength = 60;

    public static string Summarize(IEnumerable<KeyValuePair<string, object?>>? arguments)
    {
        if (arguments is null)
            return "";

        return string.Join(", ", arguments.Select(kv => $"{kv.Key}: {Truncate(kv.Value)}"));
    }

    public static string Truncate(object? value)
    {
        var text = (value?.ToString() ?? "null").Replace('\n', ' ');
        return text.Length <= MaxValueLength ? text : text[..MaxValueLength] + "…";
    }
}
