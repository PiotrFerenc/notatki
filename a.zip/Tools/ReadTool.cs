using System.ComponentModel;
using System.Text;
using CodeAgent.Workspace;

namespace CodeAgent.Tools;

public sealed class ReadTool : ITool
{
    private readonly IFileReadTracker _tracker;
    private readonly IWorkspaceGuard _workspace;

    public ReadTool(IFileReadTracker tracker, IWorkspaceGuard workspace)
    {
        _tracker = tracker;
        _workspace = workspace;
    }

    public string Name => "Read";

    public string Description =>
        "Reads a file from the local filesystem. Returns content with 1-based line numbers.";

    public bool RequiresConfirmation => false;

    public Delegate Handler => Execute;

    [Description("Reads a file from the local filesystem")]
    private string Execute(
        [Description("Absolute path to the file to read")] string filePath,
        [Description("1-based line number to start reading from")] int? offset = null,
        [Description("Maximum number of lines to read")] int? limit = null)
    {
        if (_workspace.Validate(filePath) is { } workspaceError)
            return workspaceError;

        if (!File.Exists(filePath))
            return $"Error: file not found: {filePath}";

        if (FileContentGuard.Validate(filePath) is { } contentError)
            return contentError;

        _tracker.MarkRead(filePath);

        var lines = File.ReadAllLines(filePath);
        var start = Math.Max((offset ?? 1) - 1, 0);
        if (start >= lines.Length)
            return string.Empty;

        var count = Math.Min(limit ?? 2000, lines.Length - start);
        var sb = new StringBuilder();
        for (var i = start; i < start + count; i++)
            sb.Append(i + 1).Append('\t').AppendLine(lines[i]);

        return sb.ToString();
    }
}
