using Microsoft.Extensions.AI;

namespace CodeAgent.Tools;

/// <summary>Adapter: turns an <see cref="ITool"/> into the <see cref="AITool"/> shape the agent framework
/// expects, composing whichever decorators apply (build-verify, permission gate) around it.</summary>
public interface IToolFunctionAdapter
{
    AITool Adapt(ITool tool);
}
