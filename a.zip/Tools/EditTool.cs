using System.ComponentModel;
using System.Text;
using CodeAgent.Workspace;

namespace CodeAgent.Tools;

public sealed class EditTool : ITool
{
    private readonly IFileReadTracker _tracker;
    private readonly IWorkspaceGuard _workspace;

    public EditTool(IFileReadTracker tracker, IWorkspaceGuard workspace)
    {
        _tracker = tracker;
        _workspace = workspace;
    }

    public string Name => "Edit";

    public string Description =>
        "Replaces an exact text match in a file. old_string must occur exactly once in the file.";

    public bool RequiresConfirmation => true;

    public Delegate Handler => Execute;

    public bool VerifyBuildAfterInvoke => true;

    public string? FormatConfirmation(IEnumerable<KeyValuePair<string, object?>> arguments)
    {
        var args = arguments.ToDictionary(kv => kv.Key, kv => kv.Value);
        if (!args.TryGetValue("filePath", out var filePath))
            return null;

        var oldString = args.GetValueOrDefault("oldString")?.ToString() ?? "";
        var newString = args.GetValueOrDefault("newString")?.ToString() ?? "";

        var sb = new StringBuilder();
        sb.AppendLine(filePath?.ToString());
        foreach (var line in oldString.Split('\n'))
            sb.Append("- ").AppendLine(line);
        foreach (var line in newString.Split('\n'))
            sb.Append("+ ").AppendLine(line);

        return sb.ToString();
    }

    [Description("Replaces an exact text match in a file")]
    private string Execute(
        [Description("Absolute path to the file to edit")] string filePath,
        [Description("Exact, unique text to find")] string oldString,
        [Description("Text to replace it with")] string newString)
    {
        if (_workspace.Validate(filePath) is { } workspaceError)
            return workspaceError;

        if (!File.Exists(filePath))
            return $"Error: file not found: {filePath}";

        if (!_tracker.HasBeenRead(filePath))
            return "Error: read this file with Read before editing it — you haven't seen its current contents this session.";

        if (FileContentGuard.Validate(filePath) is { } contentError)
            return contentError;

        var content = File.ReadAllText(filePath);
        var firstIndex = content.IndexOf(oldString, StringComparison.Ordinal);
        if (firstIndex < 0)
            return "Error: old_string not found in file";

        if (content.IndexOf(oldString, firstIndex + 1, StringComparison.Ordinal) >= 0)
            return "Error: old_string matches multiple locations, must be unique";

        var updated = string.Concat(
            content.AsSpan(0, firstIndex),
            newString,
            content.AsSpan(firstIndex + oldString.Length));

        File.WriteAllText(filePath, updated);
        _tracker.MarkRead(filePath);
        return $"Edited {filePath}";
    }
}
