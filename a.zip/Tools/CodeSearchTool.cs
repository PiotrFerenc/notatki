using System.ComponentModel;
using System.Text;
using CodeAgent.Search;
using CodeAgent.Workspace;

namespace CodeAgent.Tools;

public sealed class CodeSearchTool : ITool
{
    private readonly IEmbeddingIndex _index;
    private readonly IWorkspaceGuard _workspace;

    public CodeSearchTool(IEmbeddingIndex index, IWorkspaceGuard workspace)
    {
        _index = index;
        _workspace = workspace;
    }

    public string Name => "CodeSearch";

    public string Description =>
        "Semantic search over the repository: finds code relevant to a natural-language query, " +
        "even when it doesn't share exact keywords. Use this before Grep when you don't know what to grep for.";

    public bool RequiresConfirmation => false;

    public Delegate Handler => SearchAsync;

    [Description("Finds code relevant to a natural-language query using semantic search")]
    private async Task<string> SearchAsync(
        [Description("Natural-language description of what you're looking for")] string query,
        [Description("Directory to search in, defaults to the current directory")] string? path = null,
        CancellationToken cancellationToken = default)
    {
        var root = path ?? Directory.GetCurrentDirectory();
        if (_workspace.Validate(root) is { } workspaceError)
            return workspaceError;

        var hits = await _index.SearchAsync(query, root, topK: 8, cancellationToken);
        if (hits.Count == 0)
            return "No relevant code found";

        var sb = new StringBuilder();
        foreach (var hit in hits)
        {
            sb.Append(hit.File).Append(':').Append(hit.StartLine)
                .Append(" (score ").Append(hit.Score.ToString("F2")).AppendLine(")");
            sb.AppendLine(hit.Text).AppendLine("---");
        }

        return sb.ToString();
    }
}
