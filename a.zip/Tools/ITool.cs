namespace CodeAgent.Tools;

/// <summary>A single agent-callable capability (Command pattern). <see cref="Handler"/> is the
/// strongly-typed method the framework inspects via reflection to build the tool's JSON schema.</summary>
public interface ITool
{
    string Name { get; }

    string Description { get; }

    /// <summary>Whether invoking this tool must go through <see cref="Permissions.IPermissionGate"/> first.</summary>
    bool RequiresConfirmation { get; }

    Delegate Handler { get; }

    /// <summary>Whether the repo's build command should auto-run after a successful call, with the result
    /// appended to the tool's own output. Only meaningful for tools that touch files (Write/Edit).</summary>
    bool VerifyBuildAfterInvoke => false;

    /// <summary>Optional richer rendering for the permission confirmation dialog. Returning null falls back
    /// to <see cref="ToolArgumentFormatter"/>'s generic "key: value, …" summary.</summary>
    string? FormatConfirmation(IEnumerable<KeyValuePair<string, object?>> arguments) => null;
}
