using System.ComponentModel;
using System.Text;
using System.Text.RegularExpressions;
using CodeAgent.Workspace;

namespace CodeAgent.Tools;

public sealed class GrepTool : ITool
{
    private const int MaxFilesScanned = 5000;

    private readonly IWorkspaceGuard _workspace;

    public GrepTool(IWorkspaceGuard workspace)
    {
        _workspace = workspace;
    }

    public string Name => "Grep";

    public string Description => "Searches file contents recursively using a regex pattern.";

    public bool RequiresConfirmation => false;

    public Delegate Handler => Execute;

    [Description("Searches file contents recursively using a regex pattern")]
    private string Execute(
        [Description("Regex pattern to search for")] string pattern,
        [Description("Directory to search in, defaults to the current directory")] string? path = null,
        [Description("Filename glob filter, e.g. *.cs")] string? filePattern = null)
    {
        var root = path ?? Directory.GetCurrentDirectory();
        if (_workspace.Validate(root) is { } workspaceError)
            return workspaceError;

        var regex = new Regex(pattern, RegexOptions.None, TimeSpan.FromSeconds(2));
        var sb = new StringBuilder();
        var scanned = 0;
        var truncated = false;

        foreach (var file in Directory.EnumerateFiles(root, filePattern ?? "*", SearchOption.AllDirectories))
        {
            // Recursive enumeration can walk into a symlinked subdirectory that leads outside the
            // workspace even though root itself passed validation — re-check each candidate.
            if (_workspace.Validate(file) is not null)
                continue;

            if (scanned++ >= MaxFilesScanned)
            {
                truncated = true;
                break;
            }

            string[] lines;
            try
            {
                lines = File.ReadAllLines(file);
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                continue;
            }

            for (var i = 0; i < lines.Length; i++)
                if (regex.IsMatch(lines[i]))
                    sb.Append(file).Append(':').Append(i + 1).Append(':').AppendLine(lines[i]);
        }

        if (truncated)
            sb.AppendLine($"… stopped after {MaxFilesScanned} files, narrow the search with path/filePattern");

        return sb.Length == 0 ? "No matches" : sb.ToString();
    }
}
