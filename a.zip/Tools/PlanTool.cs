using System.ComponentModel;

namespace CodeAgent.Tools;

/// <summary>
/// Human checkpoint before non-trivial, multi-step work — mirrors Claude Code's plan mode. Deliberately
/// reuses the existing permission-gate infrastructure (RequiresConfirmation = true) instead of building a
/// separate approval mechanism: the plan text becomes the confirmation panel's body, "y" approves it.
/// </summary>
public sealed class PlanTool : ITool
{
    public string Name => "Plan";

    public string Description =>
        "Presents a numbered step-by-step plan for a non-trivial, multi-file, or hard-to-reverse change and " +
        "waits for the user's approval before any mutating tool runs. Call this before starting such work.";

    public bool RequiresConfirmation => true;

    public Delegate Handler => Present;

    public string? FormatConfirmation(IEnumerable<KeyValuePair<string, object?>> arguments) =>
        arguments.FirstOrDefault(kv => kv.Key == "steps").Value?.ToString();

    [Description("Presents a plan and waits for user approval")]
    private string Present([Description("Numbered steps of the plan, one per line")] string steps) =>
        "Plan approved by the user. Proceed.";
}
