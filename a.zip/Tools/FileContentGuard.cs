using System.Text;

namespace CodeAgent.Tools;

/// <summary>Refuses to load a file as text when it's implausibly large or looks binary — Read/Edit both
/// used to hand raw <c>File.ReadAllText/Lines</c> whatever was on disk, which could flood the model's
/// context with a huge log file or throw a decoder exception on a binary one.</summary>
internal static class FileContentGuard
{
    private const long MaxFileBytes = 1_000_000;
    private const int BinarySniffBytes = 8000;

    // Strict decode is the actual correct test for "is this text" — not a byte-ratio guess. Structured
    // multi-byte UTF-8 sequences are specific enough that random/compressed binary data essentially never
    // parses as valid UTF-8 for more than a few bytes, and this is exactly what ReadAllText/Lines assume
    // downstream anyway (no encoding is ever specified there, so UTF-8 is already the implicit contract).
    private static readonly UTF8Encoding StrictUtf8 = new(encoderShouldEmitUTF8Identifier: false, throwOnInvalidBytes: true);

    public static string? Validate(string filePath)
    {
        var info = new FileInfo(filePath);
        if (info.Length > MaxFileBytes)
            return $"Error: file is too large to read as text ({info.Length:N0} bytes, limit {MaxFileBytes:N0})";

        if (info.Length == 0)
            return null;

        using var stream = File.OpenRead(filePath);
        var buffer = new byte[Math.Min(BinarySniffBytes, info.Length)];
        var read = stream.Read(buffer, 0, buffer.Length);

        // NUL is technically valid UTF-8 (it's just U+0000), so the strict decode below won't catch a
        // NUL-padded binary on its own — check for it explicitly first.
        if (Array.IndexOf(buffer, (byte)0, 0, read) >= 0)
            return "Error: file appears to be binary, refusing to read it as text";

        try
        {
            StrictUtf8.GetString(buffer, 0, read);
        }
        catch (DecoderFallbackException)
        {
            return "Error: file appears to be binary (not valid UTF-8), refusing to read it as text";
        }

        return null;
    }
}
