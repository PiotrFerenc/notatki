using System.ComponentModel;
using CodeAgent.Workspace;

namespace CodeAgent.Tools;

public sealed class WriteTool : ITool
{
    private readonly IFileReadTracker _tracker;
    private readonly IWorkspaceGuard _workspace;

    public WriteTool(IFileReadTracker tracker, IWorkspaceGuard workspace)
    {
        _tracker = tracker;
        _workspace = workspace;
    }

    public string Name => "Write";

    public string Description => "Writes content to a file, creating or overwriting it.";

    public bool RequiresConfirmation => true;

    public Delegate Handler => Execute;

    public bool VerifyBuildAfterInvoke => true;

    [Description("Writes content to a file, creating or overwriting it")]
    private string Execute(
        [Description("Absolute path to the file to write")] string filePath,
        [Description("Content to write into the file")] string content)
    {
        if (_workspace.Validate(filePath) is { } workspaceError)
            return workspaceError;

        if (File.Exists(filePath) && !_tracker.HasBeenRead(filePath))
            return "Error: read this file with Read before overwriting it — you haven't seen its current contents this session.";

        var dir = Path.GetDirectoryName(filePath);
        if (!string.IsNullOrEmpty(dir))
            Directory.CreateDirectory(dir);

        File.WriteAllText(filePath, content);
        _tracker.MarkRead(filePath);
        return $"Wrote {content.Length} chars to {filePath}";
    }
}
