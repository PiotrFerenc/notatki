using System.Text.RegularExpressions;

namespace CodeAgent.Tools;

/// <summary>
/// Hard denylist for a handful of catastrophic shell patterns — checked before the permission gate even
/// asks, since "the user clicked yes" isn't informed consent for a fork bomb. This is a heuristic, not a
/// sandbox: it only stops obviously-destructive one-liners, not a determined or obfuscated attempt. Real
/// isolation would mean running Bash in a container/VM; out of scope here. IWorkspaceGuard covers the
/// separate "wrong directory" case for the other tools.
/// </summary>
internal static class DangerousCommandPatterns
{
    private static readonly Regex[] Patterns =
    [
        new(@"\brm\s+(-[a-z]*\s+)*-[a-z]*r[a-z]*f|\brm\s+(-[a-z]*\s+)*-[a-z]*f[a-z]*r", RegexOptions.IgnoreCase), // rm -rf (any flag order)
        new(@":\(\)\s*\{\s*:\s*\|\s*:\s*&?\s*\}\s*;\s*:", RegexOptions.None),                                     // classic fork bomb
        new(@"\bmkfs(\.\w+)?\b", RegexOptions.IgnoreCase),
        new(@"\bdd\s+.*\bof=/dev/", RegexOptions.IgnoreCase),
        new(@">\s*/dev/sd[a-z]\b", RegexOptions.IgnoreCase),
        new(@"\bsudo\b", RegexOptions.IgnoreCase),
        new(@"\b(curl|wget)\b[^|]*\|\s*(sudo\s+)?(sh|bash|zsh)\b", RegexOptions.IgnoreCase),                      // pipe remote script to a shell
        new(@"\bchmod\s+(-R\s+)?777\s+/\s*$", RegexOptions.IgnoreCase),
    ];

    public static bool IsDangerous(string command) => Patterns.Any(p => p.IsMatch(command));
}
