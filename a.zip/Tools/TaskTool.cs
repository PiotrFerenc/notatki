using System.ComponentModel;
using CodeAgent.Agent;

namespace CodeAgent.Tools;

/// <summary>
/// Delegates a focused sub-task to a fresh, isolated agent with its own conversation — mirrors Claude Code's
/// Task tool. The sub-agent shares the same worker tools (Read/Write/Edit/Bash/Grep/Glob/CodeSearch) and the
/// same <see cref="Permissions.IPermissionGate"/>, so its mutating calls still prompt for confirmation.
/// </summary>
public sealed class TaskTool : ITool
{
    private readonly IChatAgentBuilder _builder;
    private readonly IEnumerable<ITool> _workerTools;

    /// <param name="workerTools">
    /// The non-orchestration tools (Read/Write/Edit/Bash/Grep/Glob/CodeSearch) — deliberately excludes
    /// TaskTool itself, both to avoid a DI cycle and to bound recursion depth to one level.
    /// </param>
    public TaskTool(IChatAgentBuilder builder, IEnumerable<ITool> workerTools)
    {
        _builder = builder;
        _workerTools = workerTools;
    }

    public string Name => "Task";

    public string Description =>
        "Delegates a self-contained sub-task (e.g. 'find every caller of X and summarize') to an isolated " +
        "agent and returns its final answer. Use for exploratory work whose intermediate steps would clutter " +
        "the main conversation.";

    public bool RequiresConfirmation => false;

    public Delegate Handler => RunAsync;

    [Description("Runs a focused sub-task in an isolated agent and returns its result")]
    private async Task<string> RunAsync(
        [Description("Clear, self-contained description of the sub-task, including what result is expected")]
        string instruction,
        CancellationToken cancellationToken = default)
    {
        var subAgent = _builder.Build(_workerTools);
        var subSession = await subAgent.CreateSessionAsync(cancellationToken: cancellationToken);

        var response = await subAgent.RunAsync(instruction, subSession, cancellationToken: cancellationToken);
        return response.Text;
    }
}
