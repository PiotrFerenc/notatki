using CodeAgent.Permissions;
using CodeAgent.Verification;
using Microsoft.Extensions.AI;

namespace CodeAgent.Tools;

public sealed class ToolFunctionAdapter : IToolFunctionAdapter
{
    private readonly IPermissionGate _gate;
    private readonly IBuildVerifier _buildVerifier;

    public ToolFunctionAdapter(IPermissionGate gate, IBuildVerifier buildVerifier)
    {
        _gate = gate;
        _buildVerifier = buildVerifier;
    }

    public AITool Adapt(ITool tool)
    {
        AIFunction function = AIFunctionFactory.Create(tool.Handler, tool.Name, tool.Description);

        if (tool.VerifyBuildAfterInvoke)
            function = _buildVerifier.Wrap(function);

        if (tool.RequiresConfirmation)
            function = new PermissionGatedAIFunction(function, _gate, tool);

        return function;
    }
}
