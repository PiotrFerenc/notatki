using OpenAI;

namespace CodeAgent.Agent;

/// <summary>Factory pattern: single point that builds the configured <see cref="OpenAIClient"/>, shared by chat and embeddings.</summary>
public interface IOpenAIClientProvider
{
    OpenAIClient Client { get; }
}
