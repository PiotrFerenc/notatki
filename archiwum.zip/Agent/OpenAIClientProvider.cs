using System.ClientModel;
using CodeAgent.Config;
using Microsoft.Extensions.Options;
using OpenAI;

namespace CodeAgent.Agent;

public sealed class OpenAIClientProvider : IOpenAIClientProvider
{
    public OpenAIClient Client { get; }

    public OpenAIClientProvider(IOptions<AgentOptions> options)
    {
        var agentOptions = options.Value;
        var clientOptions = new OpenAIClientOptions();
        if (!string.IsNullOrWhiteSpace(agentOptions.BaseUrl))
            clientOptions.Endpoint = new Uri(agentOptions.BaseUrl);

        Client = new OpenAIClient(new ApiKeyCredential(agentOptions.ApiKey), clientOptions);
    }
}
