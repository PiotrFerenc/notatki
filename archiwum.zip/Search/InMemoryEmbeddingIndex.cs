using System.Collections.Concurrent;
using CodeAgent.Agent;
using CodeAgent.Config;
using CodeAgent.Workspace;
using Microsoft.Extensions.Options;
using OpenAI.Embeddings;

namespace CodeAgent.Search;

/// <summary>
/// Semantic code search backed by OpenAI embeddings, indexed lazily and cached in memory for the process lifetime.
/// ponytail: no persistent vector store — re-embeds on every process start. Upgrade to an on-disk index
/// (e.g. SQLite + vectors) if repos get large enough that re-indexing on startup becomes noticeable.
/// </summary>
public sealed class InMemoryEmbeddingIndex : IEmbeddingIndex
{
    private static readonly string[] IncludedExtensions =
        [".cs", ".ts", ".tsx", ".js", ".py", ".java", ".go", ".rs", ".md", ".json", ".yml", ".yaml", ".razor"];

    private static readonly string[] ExcludedDirs = ["bin", "obj", ".git", "node_modules", ".codeagent"];

    private const int ChunkLines = 60;
    private const long MaxFileBytes = 200_000;

    private readonly IOpenAIClientProvider _clientProvider;
    private readonly AgentOptions _options;
    private readonly IWorkspaceGuard _workspace;
    private readonly ConcurrentDictionary<string, (DateTime MTime, List<CodeChunk> Chunks)> _cache = new();

    public InMemoryEmbeddingIndex(IOpenAIClientProvider clientProvider, IOptions<AgentOptions> options, IWorkspaceGuard workspace)
    {
        _clientProvider = clientProvider;
        _options = options.Value;
        _workspace = workspace;
    }

    public async Task<IReadOnlyList<SearchHit>> SearchAsync(
        string query, string root, int topK, CancellationToken cancellationToken)
    {
        var embeddingClient = _clientProvider.Client.GetEmbeddingClient(_options.EmbeddingModel);
        await IndexAsync(embeddingClient, root, cancellationToken);

        var queryEmbedding = (await embeddingClient.GenerateEmbeddingAsync(query, cancellationToken: cancellationToken))
            .Value.ToFloats();

        return _cache.Values
            .SelectMany(entry => entry.Chunks)
            .Select(chunk => new SearchHit(
                chunk.File, chunk.StartLine, chunk.Text, CosineSimilarity(queryEmbedding.Span, chunk.Embedding.Span)))
            .OrderByDescending(hit => hit.Score)
            .Take(topK)
            .ToList();
    }

    private async Task IndexAsync(EmbeddingClient embeddingClient, string root, CancellationToken cancellationToken)
    {
        var files = Directory.EnumerateFiles(root, "*", SearchOption.AllDirectories)
            .Where(f => IncludedExtensions.Contains(Path.GetExtension(f)))
            .Where(f => !f.Split(Path.DirectorySeparatorChar).Any(ExcludedDirs.Contains))
            .Where(f => new FileInfo(f).Length <= MaxFileBytes)
            // Recursion can walk into a symlinked subdirectory leading outside the workspace even
            // though root itself was validated — re-check each candidate before embedding it.
            .Where(f => _workspace.Validate(f) is null);

        foreach (var file in files)
        {
            var mtime = File.GetLastWriteTimeUtc(file);
            if (_cache.TryGetValue(file, out var cached) && cached.MTime == mtime)
                continue;

            string[] lines;
            try
            {
                lines = File.ReadAllLines(file);
            }
            catch (IOException)
            {
                continue;
            }

            var chunks = Chunk(file, lines);
            if (chunks.Count == 0)
                continue;

            var embeddings = (await embeddingClient.GenerateEmbeddingsAsync(
                chunks.Select(c => c.Text), cancellationToken: cancellationToken)).Value;

            var withEmbeddings = chunks
                .Zip(embeddings, (chunk, embedding) => chunk with { Embedding = embedding.ToFloats() })
                .ToList();

            _cache[file] = (mtime, withEmbeddings);
        }
    }

    internal static List<CodeChunk> Chunk(string file, string[] lines)
    {
        var chunks = new List<CodeChunk>();
        for (var i = 0; i < lines.Length; i += ChunkLines)
        {
            var text = string.Join('\n', lines.Skip(i).Take(ChunkLines));
            if (!string.IsNullOrWhiteSpace(text))
                chunks.Add(new CodeChunk(file, i + 1, text, ReadOnlyMemory<float>.Empty));
        }

        return chunks;
    }

    internal static float CosineSimilarity(ReadOnlySpan<float> a, ReadOnlySpan<float> b)
    {
        float dot = 0, normA = 0, normB = 0;
        for (var i = 0; i < a.Length; i++)
        {
            dot += a[i] * b[i];
            normA += a[i] * a[i];
            normB += b[i] * b[i];
        }

        return dot / (MathF.Sqrt(normA) * MathF.Sqrt(normB) + 1e-8f);
    }
}
