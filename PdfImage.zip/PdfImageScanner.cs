// Extracts embedded images from a PDF's page objects, using only BCL (no NuGet packages) plus
// the Microsoft Agent Framework Workflows package for orchestration (see PdfImageExtractionExecutor).
//
// ponytail: parses by brute-force byte scanning for "/Subtype/Image ... stream ... endstream"
// instead of building a full xref/object model. Works for the common case (linear, unencrypted,
// scanner-generated PDFs where image streams are not nested inside compressed object streams).
// Will miss images if the PDF is encrypted, or uses PDF 1.5+ cross-reference/object streams that
// bury image objects inside compressed containers. Upgrade path: implement xref + object-stream
// parsing if you hit such a file.
//
// Images are numbered in file byte order, which usually (not guaranteed) matches page order.

using System.Text;
using System.Text.RegularExpressions;

public sealed record ExtractedImage(byte[] Bytes, string Extension, string FilterChain);

public static class PdfImageScanner
{
    static readonly Encoding Latin1 = Encoding.GetEncoding("ISO-8859-1");
    static readonly Regex ImageTag = new(@"/Subtype\s*/Image\b", RegexOptions.Compiled);
    static readonly Regex ObjStart = new(@"\d+\s+\d+\s+obj\b", RegexOptions.Compiled);

    public static List<ExtractedImage> Extract(byte[] pdf)
    {
        string text = Latin1.GetString(pdf);
        var results = new List<ExtractedImage>();

        foreach (Match tag in ImageTag.Matches(text))
        {
            int objStart = LastMatchBefore(ObjStart, text, tag.Index);
            if (objStart < 0) continue;

            int streamKw = text.IndexOf("stream", tag.Index, StringComparison.Ordinal);
            if (streamKw < 0) continue;

            string dictText = text.Substring(objStart, streamKw - objStart);

            int dataStart = streamKw + "stream".Length;
            // stream keyword is followed by CRLF or LF (per spec), never bare CR
            if (dataStart < pdf.Length && pdf[dataStart] == '\r') dataStart++;
            if (dataStart < pdf.Length && pdf[dataStart] == '\n') dataStart++;

            int endstreamIdx = text.IndexOf("endstream", dataStart, StringComparison.Ordinal);
            if (endstreamIdx < 0) continue;

            int dataEnd = endstreamIdx;
            // trim the EOL that precedes "endstream"
            if (dataEnd > dataStart && pdf[dataEnd - 1] == '\n') dataEnd--;
            if (dataEnd > dataStart && pdf[dataEnd - 1] == '\r') dataEnd--;

            byte[] raw = pdf[dataStart..dataEnd];

            try
            {
                var img = Decode(raw, dictText);
                if (img != null) results.Add(img);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"warning: skipped one image object ({ex.Message})");
            }
        }

        return results;
    }

    static int LastMatchBefore(Regex re, string text, int beforeIndex)
    {
        int best = -1;
        foreach (Match m in re.Matches(text, 0))
        {
            if (m.Index >= beforeIndex) break;
            best = m.Index;
        }
        return best;
    }

    static ExtractedImage? Decode(byte[] raw, string dictText)
    {
        var filters = ParseNameOrArray(dictText, "Filter");
        var parmsList = ParseDictOrArrayOfDicts(dictText, "DecodeParms");

        byte[] data = raw;
        string chain = filters.Count == 0 ? "(none)" : string.Join("+", filters);
        string lastFilter = filters.Count > 0 ? filters[^1] : "";

        // Apply every filter except a final image-format filter (DCT/JPX/CCITT), which is
        // the actual output encoding, not something to decode further.
        for (int i = 0; i < filters.Count; i++)
        {
            bool isLast = i == filters.Count - 1;
            string f = filters[i];
            string? parms = i < parmsList.Count ? parmsList[i] : null;

            switch (f)
            {
                case "ASCIIHexDecode":
                    data = AsciiHexDecode(data);
                    break;
                case "ASCII85Decode":
                    data = Ascii85Decode(data);
                    break;
                case "FlateDecode":
                    data = FlateDecode(data);
                    break;
                case "RunLengthDecode":
                    data = RunLengthDecode(data);
                    break;
                case "DCTDecode":
                    return new ExtractedImage(data, ".jpg", chain);
                case "JPXDecode":
                    return new ExtractedImage(data, ".jp2", chain);
                case "CCITTFaxDecode":
                    return new ExtractedImage(WrapCcittAsTiff(data, dictText, parms), ".tif", chain);
                default:
                    Console.WriteLine($"warning: unsupported filter {f}, dumping raw bytes");
                    return new ExtractedImage(data, ".bin", chain);
            }
        }

        // No format filter (or only Flate) -> raw sample data; wrap as BMP if we recognize the layout.
        int width = ParseInt(dictText, "Width") ?? ParseInt(dictText, "W") ?? 0;
        int height = ParseInt(dictText, "Height") ?? ParseInt(dictText, "H") ?? 0;
        int bpc = ParseInt(dictText, "BitsPerComponent") ?? 8;
        string colorSpace = ParseName(dictText, "ColorSpace") ?? ParseName(dictText, "CS") ?? "";

        if (width is > 0 && height is > 0 && bpc == 8 && colorSpace is "DeviceGray" or "CalGray")
            return new ExtractedImage(BmpFromGray8(data, width, height), ".bmp", chain);

        if (width is > 0 && height is > 0 && bpc == 8 && colorSpace is "DeviceRGB" or "CalRGB")
            return new ExtractedImage(BmpFromRgb8(data, width, height), ".bmp", chain);

        Console.WriteLine($"warning: raw sample data with unsupported color space '{colorSpace}'/{bpc}bpc, dumping .raw");
        return new ExtractedImage(data, ".raw", chain);
    }

    // ---- PDF dictionary mini-parser (flat, not a general PDF object parser) ----

    static string? ParseName(string dict, string key)
    {
        var m = Regex.Match(dict, $@"/{key}\s*/([A-Za-z0-9+_.#-]+)");
        return m.Success ? m.Groups[1].Value : null;
    }

    static int? ParseInt(string dict, string key)
    {
        var m = Regex.Match(dict, $@"/{key}\s+(-?\d+)");
        return m.Success ? int.Parse(m.Groups[1].Value) : null;
    }

    static List<string> ParseNameOrArray(string dict, string key)
    {
        var list = new List<string>();
        var arr = Regex.Match(dict, $@"/{key}\s*\[([^\]]*)\]");
        if (arr.Success)
        {
            foreach (Match nm in Regex.Matches(arr.Groups[1].Value, @"/([A-Za-z0-9+_.#-]+)"))
                list.Add(nm.Groups[1].Value);
            return list;
        }
        var single = ParseName(dict, key);
        if (single != null) list.Add(single);
        return list;
    }

    static List<string> ParseDictOrArrayOfDicts(string dict, string key)
    {
        var list = new List<string>();
        int keyIdx = dict.IndexOf("/" + key, StringComparison.Ordinal);
        if (keyIdx < 0) return list;

        int i = keyIdx + key.Length + 1;
        while (i < dict.Length && char.IsWhiteSpace(dict[i])) i++;
        if (i >= dict.Length) return list;

        if (dict[i] == '[')
        {
            int close = MatchingBracket(dict, i, '[', ']');
            string inner = dict.Substring(i + 1, close - i - 1);
            foreach (var sub in SplitTopLevelDicts(inner))
                list.Add(sub);
        }
        else if (i + 1 < dict.Length && dict[i] == '<' && dict[i + 1] == '<')
        {
            int close = MatchingBalanced(dict, i);
            list.Add(dict.Substring(i, close - i + 2));
        }
        return list;
    }

    static IEnumerable<string> SplitTopLevelDicts(string s)
    {
        int i = 0;
        while (i < s.Length)
        {
            if (i + 1 < s.Length && s[i] == '<' && s[i + 1] == '<')
            {
                int close = MatchingBalanced(s, i);
                yield return s.Substring(i, close - i + 2);
                i = close + 2;
            }
            else i++;
        }
    }

    static int MatchingBracket(string s, int openIdx, char open, char close)
    {
        int depth = 0;
        for (int i = openIdx; i < s.Length; i++)
        {
            if (s[i] == open) depth++;
            else if (s[i] == close && --depth == 0) return i;
        }
        return s.Length - 1;
    }

    // matches "<<" ... ">>" honoring nesting, returns index of the final '>' of the closing ">>"
    static int MatchingBalanced(string s, int openIdx)
    {
        int depth = 0;
        int i = openIdx;
        while (i < s.Length - 1)
        {
            if (s[i] == '<' && s[i + 1] == '<') { depth++; i += 2; continue; }
            if (s[i] == '>' && s[i + 1] == '>') { depth--; i += 2; if (depth == 0) return i - 1; continue; }
            i++;
        }
        return s.Length - 1;
    }

    // ---- stream filters ----

    static byte[] AsciiHexDecode(byte[] data)
    {
        var outBytes = new List<byte>(data.Length / 2);
        int hi = -1;
        foreach (byte b in data)
        {
            char c = (char)b;
            if (c == '>') break;
            int v = c switch
            {
                >= '0' and <= '9' => c - '0',
                >= 'A' and <= 'F' => c - 'A' + 10,
                >= 'a' and <= 'f' => c - 'a' + 10,
                _ => -1
            };
            if (v < 0) continue;
            if (hi < 0) hi = v;
            else { outBytes.Add((byte)((hi << 4) | v)); hi = -1; }
        }
        if (hi >= 0) outBytes.Add((byte)(hi << 4));
        return outBytes.ToArray();
    }

    static byte[] Ascii85Decode(byte[] data)
    {
        var outBytes = new List<byte>(data.Length * 4 / 5 + 4);
        var group = new int[5];
        int n = 0;
        int i = 0;
        if (data.Length >= 2 && data[0] == '<' && data[1] == '~') i = 2;
        for (; i < data.Length; i++)
        {
            char c = (char)data[i];
            if (c == '~') break;
            if (c == 'z' && n == 0) { outBytes.AddRange(new byte[4]); continue; }
            if (c < '!' || c > 'u') continue;
            group[n++] = c - '!';
            if (n == 5)
            {
                uint v = 0;
                foreach (int g in group) v = v * 85 + (uint)g;
                outBytes.Add((byte)(v >> 24)); outBytes.Add((byte)(v >> 16));
                outBytes.Add((byte)(v >> 8)); outBytes.Add((byte)v);
                n = 0;
            }
        }
        if (n > 0)
        {
            int pad = 5 - n;
            for (int k = n; k < 5; k++) group[k] = 84;
            uint v = 0;
            foreach (int g in group) v = v * 85 + (uint)g;
            var bytes = new byte[] { (byte)(v >> 24), (byte)(v >> 16), (byte)(v >> 8), (byte)v };
            outBytes.AddRange(bytes[..(4 - pad)]);
        }
        return outBytes.ToArray();
    }

    public static byte[] FlateDecode(byte[] data)
    {
        using var input = new MemoryStream(data);
        using var zlib = new System.IO.Compression.ZLibStream(input, System.IO.Compression.CompressionMode.Decompress);
        using var output = new MemoryStream();
        zlib.CopyTo(output);
        return output.ToArray();
    }

    static byte[] RunLengthDecode(byte[] data)
    {
        var outBytes = new List<byte>(data.Length * 2);
        int i = 0;
        while (i < data.Length)
        {
            byte len = data[i++];
            if (len == 128) break;
            if (len < 128)
            {
                int count = len + 1;
                for (int k = 0; k < count && i < data.Length; k++) outBytes.Add(data[i++]);
            }
            else
            {
                if (i >= data.Length) break;
                byte b = data[i++];
                int count = 257 - len;
                for (int k = 0; k < count; k++) outBytes.Add(b);
            }
        }
        return outBytes.ToArray();
    }

    // ---- raw-sample -> BMP wrapping (top-down BMP, so no row-flip needed) ----

    static byte[] BmpFromGray8(byte[] data, int width, int height)
    {
        int rowBytes = width * 3;
        int pad = (4 - rowBytes % 4) % 4;
        int stride = rowBytes + pad;
        var pixels = new byte[stride * height];
        int srcStride = width; // 1 byte/pixel source, no source padding assumed (matches PDF sample rows)
        for (int y = 0; y < height; y++)
        {
            int srcRow = y * srcStride;
            int dstRow = y * stride;
            for (int x = 0; x < width; x++)
            {
                if (srcRow + x >= data.Length) break;
                byte g = data[srcRow + x];
                int d = dstRow + x * 3;
                pixels[d] = g; pixels[d + 1] = g; pixels[d + 2] = g;
            }
        }
        return BuildBmp(pixels, width, height, stride);
    }

    static byte[] BmpFromRgb8(byte[] data, int width, int height)
    {
        int rowBytes = width * 3;
        int pad = (4 - rowBytes % 4) % 4;
        int stride = rowBytes + pad;
        var pixels = new byte[stride * height];
        int srcStride = width * 3;
        for (int y = 0; y < height; y++)
        {
            int srcRow = y * srcStride;
            int dstRow = y * stride;
            for (int x = 0; x < width; x++)
            {
                int s = srcRow + x * 3;
                if (s + 2 >= data.Length) break;
                int d = dstRow + x * 3;
                pixels[d] = data[s + 2];     // B
                pixels[d + 1] = data[s + 1]; // G
                pixels[d + 2] = data[s];     // R
            }
        }
        return BuildBmp(pixels, width, height, stride);
    }

    static byte[] BuildBmp(byte[] pixels, int width, int height, int stride)
    {
        using var ms = new MemoryStream();
        using var w = new BinaryWriter(ms);
        int fileSize = 14 + 40 + pixels.Length;
        w.Write((byte)'B'); w.Write((byte)'M');
        w.Write(fileSize);
        w.Write(0); // reserved
        w.Write(14 + 40); // pixel data offset
        // BITMAPINFOHEADER
        w.Write(40);
        w.Write(width);
        w.Write(-height); // negative = top-down, avoids row-flip
        w.Write((short)1); // planes
        w.Write((short)24); // bpp
        w.Write(0); // BI_RGB
        w.Write(pixels.Length);
        w.Write(2835); w.Write(2835); // ~72 DPI
        w.Write(0); w.Write(0);
        w.Write(pixels);
        return ms.ToArray();
    }

    // ---- CCITTFaxDecode -> minimal TIFF wrapper ----

    static byte[] WrapCcittAsTiff(byte[] data, string dictText, string? parms)
    {
        string p = parms ?? dictText;
        int k = ParseInt(p, "K") ?? 0;
        int columns = ParseInt(p, "Columns") ?? 1728;
        int rows = ParseInt(p, "Rows") ?? 0;
        bool blackIs1 = Regex.IsMatch(p, @"/BlackIs1\s+true");

        if (rows <= 0) rows = ParseInt(dictText, "Height") ?? ParseInt(dictText, "H") ?? 0;
        if (rows <= 0) throw new InvalidOperationException("CCITT image missing row/height info");

        ushort compression = k < 0 ? (ushort)4 : (ushort)3; // Group4 (T.6) or Group3 (T.4)
        ushort photometric = blackIs1 ? (ushort)1 : (ushort)0; // BlackIsZero : WhiteIsZero, see PDF BlackIs1 spec

        using var ms = new MemoryStream();
        using var w = new BinaryWriter(ms);

        w.Write((byte)'I'); w.Write((byte)'I'); w.Write((ushort)42);
        int ifdOffsetPos = (int)ms.Position;
        w.Write(0); // placeholder, patched below

        int dataOffset = (int)ms.Position;
        w.Write(data);

        int ifdStart = (int)ms.Position;
        var entries = new List<(ushort tag, ushort type, uint count, uint value)>
        {
            (256, 4, 1, (uint)columns),      // ImageWidth, LONG
            (257, 4, 1, (uint)rows),         // ImageLength, LONG
            (258, 3, 1, 1),                  // BitsPerSample, SHORT
            (259, 3, 1, compression),        // Compression, SHORT
            (262, 3, 1, photometric),        // PhotometricInterpretation, SHORT
            (273, 4, 1, (uint)dataOffset),   // StripOffsets, LONG
            (277, 3, 1, 1),                  // SamplesPerPixel, SHORT
            (278, 4, 1, (uint)rows),         // RowsPerStrip, LONG
            (279, 4, 1, (uint)data.Length),  // StripByteCounts, LONG
        };

        w.Write((ushort)entries.Count);
        foreach (var e in entries)
        {
            w.Write(e.tag);
            w.Write(e.type);
            w.Write(e.count);
            if (e.type == 3) { w.Write((ushort)e.value); w.Write((ushort)0); } // SHORT stored left-justified in 4 bytes
            else w.Write(e.value);
        }
        w.Write(0); // next IFD offset (none)

        ms.Position = ifdOffsetPos;
        w.Write(ifdStart);

        return ms.ToArray();
    }
}

public static class SelfTest
{
    public static void Run()
    {
        Assert(RoundtripFlate(), "FlateDecode roundtrip");
        Assert(AsciiHexKnownVector(), "ASCIIHexDecode known vector");
        Assert(Ascii85KnownVector(), "ASCII85Decode known vector");
        Console.WriteLine("selftest OK");
    }

    static void Assert(bool cond, string what)
    {
        if (!cond) throw new Exception($"selftest FAILED: {what}");
    }

    static bool RoundtripFlate()
    {
        byte[] original = Encoding.ASCII.GetBytes("the quick brown fox jumps over the lazy dog 1234567890");
        using var compressed = new MemoryStream();
        using (var z = new System.IO.Compression.ZLibStream(compressed, System.IO.Compression.CompressionLevel.Optimal, leaveOpen: true))
            z.Write(original, 0, original.Length);
        byte[] decoded = PdfImageScanner.FlateDecode(compressed.ToArray());
        return decoded.SequenceEqual(original);
    }

    static bool AsciiHexKnownVector()
    {
        // "48656C6C6F" -> "Hello"
        byte[] input = Encoding.ASCII.GetBytes("48656C6C6F>");
        byte[] expected = Encoding.ASCII.GetBytes("Hello");
        byte[] got = (byte[])typeof(PdfImageScanner)
            .GetMethod("AsciiHexDecode", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic)!
            .Invoke(null, new object[] { input })!;
        return got.SequenceEqual(expected);
    }

    static bool Ascii85KnownVector()
    {
        // "Man " -> "9jqo^" in Adobe ASCII85 (classic test vector, first 4 bytes)
        byte[] input = Encoding.ASCII.GetBytes("9jqo^~>");
        byte[] expected = Encoding.ASCII.GetBytes("Man ");
        byte[] got = (byte[])typeof(PdfImageScanner)
            .GetMethod("Ascii85Decode", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic)!
            .Invoke(null, new object[] { input })!;
        return got.SequenceEqual(expected);
    }
}
