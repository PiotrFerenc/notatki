using Microsoft.Agents.AI.Workflows;

public sealed record PdfExtractionRequest(string PdfPath, string OutputDir);

public sealed record ExtractedPage(int PageNumber, string ImagePath, string Base64Path, string Base64);

public sealed record PdfExtractionResult(int ImageCount, IReadOnlyList<ExtractedPage> Pages);

public sealed partial class PdfImageExtractionExecutor() : Executor(nameof(PdfImageExtractionExecutor))
{
    // Yield lets a standalone run of this single executor observe the result (see PdfImageExtractor's
    // own Program.cs); Send lets a bigger workflow route it on to a downstream node via an edge.
    [MessageHandler(Yield = [typeof(PdfExtractionResult)], Send = [typeof(PdfExtractionResult)])]
    public async ValueTask HandleAsync(PdfExtractionRequest request, IWorkflowContext context, CancellationToken cancellationToken)
    {
        Directory.CreateDirectory(request.OutputDir);

        byte[] pdf = await File.ReadAllBytesAsync(request.PdfPath, cancellationToken);
        var images = PdfImageScanner.Extract(pdf);

        var pages = new List<ExtractedPage>();
        int i = 0;
        foreach (var img in images)
        {
            i++;
            string imagePath = Path.Combine(request.OutputDir, $"image{i:D3}{img.Extension}");
            string b64Path = Path.Combine(request.OutputDir, $"image{i:D3}.b64.txt");
            string base64 = Convert.ToBase64String(img.Bytes);
            await File.WriteAllBytesAsync(imagePath, img.Bytes, cancellationToken);
            await File.WriteAllTextAsync(b64Path, base64, cancellationToken);
            pages.Add(new ExtractedPage(i, imagePath, b64Path, base64));
        }

        var result = new PdfExtractionResult(images.Count, pages);
        await context.YieldOutputAsync(result, cancellationToken);
        await context.SendMessageAsync(result, cancellationToken);
    }
}
